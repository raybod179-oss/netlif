# سایت خبری لاراول — پروژه‌ی دوم دوره‌ی «Laravel از صفر تا ۱۰۰۰»
ساخته‌شده توسط Rayvo (رایبد اکبرلو) برای همین دوره.

نصب: دستورهای صفحه‌ی پروژه در دوره را دنبال کن.

ادمین: admin@news.test / password — کاربر: user@news.test / password
قبل از انتشار: گذرواژه‌ها را عوض کن، APP_DEBUG=false، APP_ENV=production.
