<?php
namespace App\Http\Controllers;
use App\Models\{Category, Post};
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $q = trim((string) $request->query('q'));
        $posts = Post::published()->with(['category', 'author'])
            ->when($q !== '', fn ($query) => $query->where('title', 'like', "%{$q}%"))
            ->latest('published_at')->paginate(9)->withQueryString();

        return view('home', ['posts' => $posts, 'q' => $q, 'categories' => Category::orderBy('name')->get(), 'current' => null]);
    }

    public function category(Category $category)
    {
        $posts = $category->posts()->published()->with(['category', 'author'])->latest('published_at')->paginate(9);
        return view('home', ['posts' => $posts, 'q' => '', 'categories' => Category::orderBy('name')->get(), 'current' => $category]);
    }

    public function show(Request $request, Post $post)
    {
        $isAdmin = $request->user()?->isAdmin();
        abort_unless($isAdmin || ($post->status === 'published' && $post->published_at?->isPast()), 404);

        if (! $isAdmin) { $post->increment('views'); }

        $post->load(['category', 'author']);
        $comments = $post->comments()->where('approved', true)->with('user')->latest()->get();
        return view('post', compact('post', 'comments'));
    }
}
