<?php
namespace App\Http\Controllers;
use App\Models\Post;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function store(Request $request, Post $post)
    {
        abort_unless($post->status === 'published', 404);
        $data = $request->validate(['body' => 'required|string|min:3|max:1000']);
        $post->comments()->create($data + ['user_id' => $request->user()->id, 'approved' => false]);
        return back()->with('success', 'دیدگاه شما ثبت شد و پس از تأیید مدیر نمایش داده می‌شود.');
    }
}
