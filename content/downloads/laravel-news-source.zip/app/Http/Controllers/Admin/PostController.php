<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{Category, Post};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PostController extends Controller
{
    private function rules(): array
    {
        return [
            'title' => 'required|string|max:200',
            'excerpt' => 'required|string|max:300',
            'body' => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'status' => 'required|in:draft,published',
            'image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ];
    }

    public function index()
    {
        return view('admin.posts.index', ['posts' => Post::with('category')->latest()->paginate(15)]);
    }

    public function create()
    {
        return view('admin.posts.form', ['post' => new Post(['status' => 'draft']), 'categories' => Category::orderBy('name')->get()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate($this->rules());
        $data['published_at'] = $data['status'] === 'published' ? now() : null;
        if ($request->hasFile('image')) { $data['image'] = $request->file('image')->store('posts', 'public'); }
        $request->user()->posts()->create($data);
        return redirect()->route('admin.posts.index')->with('success', 'خبر ایجاد شد.');
    }

    public function edit(Post $post)
    {
        return view('admin.posts.form', ['post' => $post, 'categories' => Category::orderBy('name')->get()]);
    }

    public function update(Request $request, Post $post)
    {
        $data = $request->validate($this->rules());
        if ($data['status'] === 'published') { $data['published_at'] = $post->published_at ?? now(); }
        else { $data['published_at'] = null; }

        if ($request->hasFile('image')) {
            if ($post->image) { Storage::disk('public')->delete($post->image); }
            $data['image'] = $request->file('image')->store('posts', 'public');
        } else { unset($data['image']); }

        $post->update($data);
        return redirect()->route('admin.posts.index')->with('success', 'خبر ویرایش شد.');
    }

    public function destroy(Post $post)
    {
        if ($post->image) { Storage::disk('public')->delete($post->image); }
        $post->delete();
        return back()->with('success', 'خبر حذف شد.');
    }
}
