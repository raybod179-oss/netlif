<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{Comment, Post, User};

class DashboardController extends Controller
{
    public function index()
    {
        return view('admin.dashboard', [
            'stats' => [
                'مجموع خبرها' => Post::count(),
                'منتشرشده' => Post::where('status', 'published')->count(),
                'کاربران' => User::count(),
                'دیدگاه در انتظار تأیید' => Comment::where('approved', false)->count(),
            ],
            'latest' => Post::with('category')->latest()->limit(5)->get(),
        ]);
    }
}
