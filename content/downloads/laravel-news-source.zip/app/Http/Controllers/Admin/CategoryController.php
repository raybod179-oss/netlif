<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index() { return view('admin.categories', ['categories' => Category::withCount('posts')->orderBy('name')->get()]); }

    public function store(Request $request)
    {
        Category::create($request->validate(['name' => 'required|string|max:60|unique:categories,name']));
        return back()->with('success', 'دسته ساخته شد.');
    }

    public function destroy(Category $category)
    {
        if ($category->posts()->exists()) { return back()->with('error', 'این دسته خبر دارد و حذف نمی‌شود.'); }
        $category->delete();
        return back()->with('success', 'دسته حذف شد.');
    }
}
