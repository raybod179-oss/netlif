<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Comment;

class CommentController extends Controller
{
    public function index() { return view('admin.comments', ['comments' => Comment::with(['user', 'post'])->orderBy('approved')->latest()->paginate(20)]); }
    public function approve(Comment $comment) { $comment->update(['approved' => true]); return back()->with('success', 'دیدگاه تأیید شد.'); }
    public function destroy(Comment $comment) { $comment->delete(); return back()->with('success', 'دیدگاه حذف شد.'); }
}
