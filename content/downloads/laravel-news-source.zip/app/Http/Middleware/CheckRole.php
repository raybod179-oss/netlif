<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** استفاده در روت: CheckRole::class.':admin' (بعد از auth) */
class CheckRole
{
    public function handle(Request $request, Closure $next, string $role): Response
    {
        abort_unless($request->user() && $request->user()->role === $role, 403, 'دسترسی مجاز نیست.');
        return $next($request);
    }
}
