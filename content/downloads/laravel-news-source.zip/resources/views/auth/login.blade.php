<x-layout title="ورود">
<form class="box" method="post" action="{{ route('login') }}" style="max-width:420px;margin:30px auto">@csrf
    <h2>ورود</h2>
    <label>ایمیل</label><input type="email" name="email" value="{{ old('email') }}" required>
    @error('email')<div class="fe">{{ $message }}</div>@enderror
    <label>گذرواژه</label><input type="password" name="password" required>
    <p><label style="font-weight:400"><input type="checkbox" name="remember" style="width:auto"> مرا به خاطر بسپار</label></p>
    <button>ورود</button>
</form>
</x-layout>
