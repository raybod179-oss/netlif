<x-layout title="ثبت‌نام">
<form class="box" method="post" action="{{ route('register') }}" style="max-width:420px;margin:30px auto">@csrf
    <h2>ثبت‌نام</h2>
    @foreach(['name' => 'نام', 'email' => 'ایمیل'] as $f => $l)
        <label>{{ $l }}</label><input name="{{ $f }}" value="{{ old($f) }}" required>
        @error($f)<div class="fe">{{ $message }}</div>@enderror
    @endforeach
    <label>گذرواژه (حداقل ۸ کاراکتر)</label><input type="password" name="password" required>
    @error('password')<div class="fe">{{ $message }}</div>@enderror
    <label>تکرار گذرواژه</label><input type="password" name="password_confirmation" required>
    <p><button>ساخت حساب</button></p>
</form>
</x-layout>
