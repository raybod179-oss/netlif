<x-layout title="خانه">
    <div class="cats">
        <a href="{{ route('home') }}" @class(['on' => ! $current])>همه</a>
        @foreach($categories as $c)<a href="{{ route('category', $c) }}" @class(['on' => $current?->id === $c->id])>{{ $c->name }}</a>@endforeach
    </div>
    @if($q !== '')<p class="meta">نتیجه‌ی جستجو برای «{{ $q }}»</p>@endif
    <div class="grid">
        @forelse($posts as $post)
            <article class="card">
                @if($post->imageUrl())<img src="{{ $post->imageUrl() }}" alt="{{ $post->title }}">@else<img alt="" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6'/>">@endif
                <div class="b">
                    <span class="meta">{{ $post->category->name }} · {{ $post->published_at->format('Y/m/d') }}</span>
                    <h3><a href="{{ route('posts.show', $post) }}">{{ $post->title }}</a></h3>
                    <p class="meta">{{ $post->excerpt }}</p>
                </div>
            </article>
        @empty
            <p>خبری پیدا نشد.</p>
        @endforelse
    </div>
    @include('partials.pager', ['items' => $posts])
</x-layout>
