@props(['title' => 'پنل مدیریت'])
<x-layout :title="$title">
    <nav class="cats">
        <a href="{{ route('admin.dashboard') }}" @class(['on' => request()->routeIs('admin.dashboard')])>داشبورد</a>
        <a href="{{ route('admin.posts.index') }}" @class(['on' => request()->routeIs('admin.posts.*')])>خبرها</a>
        <a href="{{ route('admin.categories.index') }}" @class(['on' => request()->routeIs('admin.categories.*')])>دسته‌ها</a>
        <a href="{{ route('admin.comments.index') }}" @class(['on' => request()->routeIs('admin.comments.*')])>دیدگاه‌ها</a>
    </nav>
    {{ $slot }}
</x-layout>
