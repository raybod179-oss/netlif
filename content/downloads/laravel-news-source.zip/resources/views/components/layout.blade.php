@props(['title' => 'خبرنگار'])
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title }} | سایت خبری Rayvo</title>
    <link rel="stylesheet" href="{{ asset('css/news.css') }}">
</head>
<body>
<header class="top"><div class="wrap">
    <a href="{{ route('home') }}"><b>📰 سایت خبری</b></a>
    <form class="search" action="{{ route('home') }}"><input name="q" value="{{ request('q') }}" placeholder="جستجو در خبرها"><button>جستجو</button></form>
    <span class="sp"></span>
    @auth
        @if(auth()->user()->isAdmin())<a href="{{ route('admin.dashboard') }}">پنل مدیریت</a>@endif
        <span>{{ auth()->user()->name }}</span>
        <form method="post" action="{{ route('logout') }}">@csrf<button class="gray">خروج</button></form>
    @else
        <a href="{{ route('login') }}">ورود</a><a href="{{ route('register') }}">ثبت‌نام</a>
    @endauth
</div></header>
<main class="wrap">
    @if(session('success'))<div class="alert ok">{{ session('success') }}</div>@endif
    @if(session('error'))<div class="alert err">{{ session('error') }}</div>@endif
    {{ $slot }}
</main>
<footer>پروژه‌ی دوم دوره‌ی «Laravel از صفر تا ۱۰۰۰» · ساخته‌شده توسط Rayvo — رایبد اکبرلو</footer>
</body>
</html>
