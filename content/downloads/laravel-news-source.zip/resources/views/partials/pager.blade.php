@if($items->hasPages())
<div class="pager">
    @if($items->previousPageUrl())<a class="btn gray" href="{{ $items->previousPageUrl() }}">← قبلی</a>@else<span></span>@endif
    <span class="meta">صفحه‌ی {{ $items->currentPage() }} از {{ $items->lastPage() }}</span>
    @if($items->nextPageUrl())<a class="btn gray" href="{{ $items->nextPageUrl() }}">بعدی →</a>@else<span></span>@endif
</div>
@endif
