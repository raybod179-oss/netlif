<x-layout :title="$post->title">
    <article class="box article">
        <span class="meta">{{ $post->category->name }} · {{ $post->author->name }} · {{ $post->published_at?->format('Y/m/d') ?? 'پیش‌نویس' }} · {{ $post->views }} بازدید</span>
        <h1>{{ $post->title }}</h1>
        @if($post->imageUrl())<img src="{{ $post->imageUrl() }}" alt="{{ $post->title }}">@endif
        {!! nl2br(e($post->body)) !!}
    </article>
    <section class="box">
        <h3>دیدگاه‌ها ({{ $comments->count() }})</h3>
        @foreach($comments as $c)<p><b>{{ $c->user->name }}</b><br>{{ $c->body }}</p><hr>@endforeach
        @auth
            <form method="post" action="{{ route('comments.store', $post) }}">@csrf
                <label>دیدگاه شما</label><textarea name="body" rows="3" required>{{ old('body') }}</textarea>
                @error('body')<div class="fe">{{ $message }}</div>@enderror
                <p><button>ارسال</button></p>
            </form>
        @else
            <p><a href="{{ route('login') }}">برای ثبت دیدگاه وارد شوید.</a></p>
        @endauth
    </section>
</x-layout>
