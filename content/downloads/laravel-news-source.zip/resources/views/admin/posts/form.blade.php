<x-admin :title="$post->exists ? 'ویرایش خبر' : 'خبر جدید'">
<form class="box" method="post" enctype="multipart/form-data"
      action="{{ $post->exists ? route('admin.posts.update', $post) : route('admin.posts.store') }}">
    @csrf @if($post->exists) @method('PUT') @endif
    <label>عنوان</label><input name="title" value="{{ old('title', $post->title) }}" required>
    <label>خلاصه (حداکثر ۳۰۰ کاراکتر)</label><input name="excerpt" value="{{ old('excerpt', $post->excerpt) }}" required>
    <label>متن خبر</label><textarea name="body" rows="10" required>{{ old('body', $post->body) }}</textarea>
    <label>دسته</label>
    <select name="category_id">@foreach($categories as $c)<option value="{{ $c->id }}" @selected(old('category_id', $post->category_id) == $c->id)>{{ $c->name }}</option>@endforeach</select>
    <label>وضعیت</label>
    <select name="status"><option value="draft" @selected(old('status', $post->status) === 'draft')>پیش‌نویس</option><option value="published" @selected(old('status', $post->status) === 'published')>منتشر شود</option></select>
    <label>تصویر (jpg/png/webp، حداکثر ۲ مگابایت)</label><input type="file" name="image" accept="image/*">
    @if($post->imageUrl())<p><img src="{{ $post->imageUrl() }}" alt="" style="max-height:90px"></p>@endif
    @if($errors->any())<div class="alert err">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
    <p><button>ذخیره</button></p>
</form>
</x-admin>
