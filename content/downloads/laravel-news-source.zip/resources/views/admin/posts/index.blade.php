<x-admin title="خبرها">
    <p><a class="btn" href="{{ route('admin.posts.create') }}">+ خبر جدید</a></p>
    <table><tr><th>عنوان</th><th>دسته</th><th>وضعیت</th><th>بازدید</th><th></th></tr>
    @foreach($posts as $p)
        <tr><td>{{ $p->title }}</td><td>{{ $p->category->name }}</td><td>{{ $p->status === 'published' ? 'منتشر شده' : 'پیش‌نویس' }}</td><td>{{ $p->views }}</td>
        <td style="white-space:nowrap"><a class="btn gray" href="{{ route('admin.posts.edit', $p) }}">ویرایش</a>
        <form method="post" action="{{ route('admin.posts.destroy', $p) }}" style="display:inline" onsubmit="return confirm('حذف شود؟')">@csrf @method('DELETE')<button class="red">حذف</button></form></td></tr>
    @endforeach</table>
    @include('partials.pager', ['items' => $posts])
</x-admin>
