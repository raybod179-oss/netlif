<x-admin title="دسته‌ها">
<form class="box" method="post" action="{{ route('admin.categories.store') }}" style="display:flex;gap:8px">@csrf
    <input name="name" placeholder="نام دسته‌ی جدید" required><button>افزودن</button></form>
@error('name')<div class="fe">{{ $message }}</div>@enderror
<table>@foreach($categories as $c)<tr><td>{{ $c->name }}</td><td>{{ $c->posts_count }} خبر</td>
<td><form method="post" action="{{ route('admin.categories.destroy', $c) }}">@csrf @method('DELETE')<button class="red">حذف</button></form></td></tr>@endforeach</table>
</x-admin>
