<x-admin title="داشبورد">
    <div class="stats">@foreach($stats as $label => $n)<div class="box"><b>{{ $n }}</b>{{ $label }}</div>@endforeach</div>
    <div class="box"><h3>آخرین خبرها</h3><table>
        @foreach($latest as $p)<tr><td>{{ $p->title }}</td><td>{{ $p->category->name }}</td><td>{{ $p->status === 'published' ? 'منتشر شده' : 'پیش‌نویس' }}</td></tr>@endforeach
    </table></div>
</x-admin>
