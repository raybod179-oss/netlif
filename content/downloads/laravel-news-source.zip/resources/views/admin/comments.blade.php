<x-admin title="دیدگاه‌ها">
<table><tr><th>کاربر</th><th>دیدگاه</th><th>خبر</th><th>وضعیت</th><th></th></tr>
@foreach($comments as $c)<tr><td>{{ $c->user->name }}</td><td>{{ $c->body }}</td><td>{{ $c->post->title }}</td><td>{{ $c->approved ? 'تأییدشده' : 'در انتظار' }}</td>
<td style="white-space:nowrap">
@unless($c->approved)<form method="post" action="{{ route('admin.comments.approve', $c) }}" style="display:inline">@csrf @method('PATCH')<button>تأیید</button></form>@endunless
<form method="post" action="{{ route('admin.comments.destroy', $c) }}" style="display:inline">@csrf @method('DELETE')<button class="red">حذف</button></form></td></tr>@endforeach</table>
@include('partials.pager', ['items' => $comments])
</x-admin>
