<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::create('posts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('category_id')->constrained()->cascadeOnDelete();
            $t->string('title');
            $t->string('excerpt', 300);
            $t->text('body');
            $t->string('image')->nullable();
            $t->string('status')->default('draft')->index();
            $t->timestamp('published_at')->nullable()->index();
            $t->unsignedInteger('views')->default(0);
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('posts'); }
};
