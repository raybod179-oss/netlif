<?php
namespace Database\Seeders;
use App\Models\{Category, Comment, Post, User};
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::forceCreate(['name' => 'مدیر سایت', 'email' => 'admin@news.test', 'password' => Hash::make('password'), 'role' => 'admin']);
        $user = User::forceCreate(['name' => 'کاربر نمونه', 'email' => 'user@news.test', 'password' => Hash::make('password'), 'role' => 'user']);

        $cats = collect(['فناوری', 'ورزش', 'اقتصاد', 'فرهنگ'])->map(fn ($n) => Category::create(['name' => $n]));

        foreach (range(1, 12) as $i) {
            $post = Post::create([
                'user_id' => $admin->id,
                'category_id' => $cats[$i % 4]->id,
                'title' => "خبر نمونه‌ی شماره {$i}",
                'excerpt' => 'این یک خلاصه‌ی کوتاه برای خبر نمونه است تا فهرست خبرها پُر شود.',
                'body' => "متن کامل خبر نمونه‌ی {$i}.\n\nاین متن را از پنل مدیریت ویرایش یا حذف کن و خبر واقعی بنویس.",
                'status' => 'published',
                'published_at' => now()->subDays(13 - $i),
                'views' => rand(10, 500),
            ]);
            if ($i % 3 === 0) {
                Comment::create(['post_id' => $post->id, 'user_id' => $user->id, 'body' => 'دیدگاه تأییدشده‌ی نمونه', 'approved' => true]);
            }
        }
    }
}
