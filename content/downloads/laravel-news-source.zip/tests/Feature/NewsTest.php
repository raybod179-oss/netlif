<?php
namespace Tests\Feature;
use App\Models\{Category, Post, User};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class NewsTest extends TestCase
{
    use RefreshDatabase;

    private function user(string $role = 'user'): User
    {
        return User::forceCreate(['name' => 'T', 'email' => $role.'@t.test', 'password' => bcrypt('password'), 'role' => $role]);
    }

    public function test_home_page_loads(): void { $this->get('/')->assertOk(); }

    public function test_admin_area_is_protected(): void
    {
        $this->get('/admin')->assertRedirect('/login');
        $this->actingAs($this->user())->get('/admin')->assertForbidden();
        $this->actingAs($this->user('admin'))->get('/admin')->assertOk();
    }

    public function test_admin_can_publish_and_guest_can_read(): void
    {
        $admin = $this->user('admin');
        $cat = Category::create(['name' => 'تست']);
        $this->actingAs($admin)->post('/admin/posts', [
            'title' => 'سلام', 'excerpt' => 'خلاصه', 'body' => 'متن', 'category_id' => $cat->id, 'status' => 'published',
        ])->assertRedirect('/admin/posts');
        auth()->logout();
        $this->get('/posts/'.Post::first()->id)->assertOk()->assertSee('سلام');
    }

    public function test_comment_needs_login_and_waits_for_approval(): void
    {
        $admin = $this->user('admin');
        $cat = Category::create(['name' => 'تست']);
        $post = $admin->posts()->create(['category_id' => $cat->id, 'title' => 'a', 'excerpt' => 'b', 'body' => 'c', 'status' => 'published', 'published_at' => now()->subMinute()]);
        $this->post("/posts/{$post->id}/comments", ['body' => 'سلام'])->assertRedirect('/login');
        $this->actingAs($this->user())->post("/posts/{$post->id}/comments", ['body' => 'دیدگاه تست'])->assertRedirect();
        $this->assertDatabaseHas('comments', ['body' => 'دیدگاه تست', 'approved' => false]);
    }
}
