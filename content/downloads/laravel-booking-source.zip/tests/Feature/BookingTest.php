<?php
namespace Tests\Feature;
use App\Models\{Booking, Service, User};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BookingTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['booking.off_days' => [], 'booking.lead_minutes' => 0]);
    }

    private function user(string $email = 'u@t.test', string $role = 'user'): User
    {
        return User::forceCreate(['name' => 'T', 'email' => $email, 'password' => bcrypt('password'), 'role' => $role]);
    }
    private function service(): Service
    {
        return Service::create(['name' => 's', 'duration' => 30, 'price' => 100000, 'is_active' => true]);
    }

    public function test_guest_must_login_to_book(): void { $this->get('/book')->assertRedirect('/login'); }

    public function test_user_can_book_and_slot_becomes_taken(): void
    {
        $s = $this->service(); $date = today()->addDays(2)->toDateString();
        $this->actingAs($this->user())->post('/book', ['service_id' => $s->id, 'date' => $date, 'start_time' => '10:00'])->assertRedirect('/my-bookings');
        $this->assertDatabaseHas('bookings', ['start_time' => '10:00', 'status' => 'pending']);
        $slot = collect($this->getJson("/book/slots?service_id={$s->id}&date={$date}")->json())->firstWhere('start', '10:00');
        $this->assertFalse($slot['free']);
    }

    public function test_double_booking_is_rejected(): void
    {
        $s = $this->service(); $date = today()->addDays(2)->toDateString();
        $this->actingAs($this->user('a@t.test'))->post('/book', ['service_id' => $s->id, 'date' => $date, 'start_time' => '11:00']);
        $this->actingAs($this->user('b@t.test'))->post('/book', ['service_id' => $s->id, 'date' => $date, 'start_time' => '11:00'])->assertSessionHasErrors('start_time');
        $this->assertSame(1, Booking::count());
    }

    public function test_user_cannot_cancel_someone_elses_booking(): void
    {
        $s = $this->service(); $owner = $this->user('o@t.test');
        $b = Booking::create(['user_id' => $owner->id, 'service_id' => $s->id, 'date' => today()->addDays(3), 'start_time' => '09:00', 'end_time' => '09:30', 'price' => 1, 'status' => 'pending']);
        $this->actingAs($this->user('x@t.test'))->patch("/my-bookings/{$b->id}/cancel")->assertForbidden();
    }

    public function test_admin_area_is_protected(): void
    {
        $this->actingAs($this->user())->get('/admin')->assertForbidden();
        $this->actingAs($this->user('ad@t.test', 'admin'))->get('/admin')->assertOk();
    }
}
