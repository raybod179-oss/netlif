# سیستم رزرو وقت لاراول — پروژه‌ی سوم دوره‌ی «Laravel از صفر تا ۱۰۰۰»
ساخته‌شده توسط Rayvo (رایبد اکبرلو) برای همین دوره.
ادمین: admin@book.test / password — کاربر: user@book.test / password
ساعت کار و روزهای تعطیل: config/booking.php
