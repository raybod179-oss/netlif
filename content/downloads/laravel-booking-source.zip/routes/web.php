<?php
use App\Http\Controllers\{AuthController, BookingController, HomeController};
use App\Http\Controllers\Admin;
use App\Http\Middleware\CheckRole;
use Illuminate\Support\Facades\Route;

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/book/slots', [BookingController::class, 'slots'])->middleware('throttle:60,1')->name('book.slots');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:5,1');
});
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

Route::middleware('auth')->group(function () {
    Route::get('/book', [BookingController::class, 'create'])->name('book.create');
    Route::post('/book', [BookingController::class, 'store'])->middleware('throttle:10,1')->name('book.store');
    Route::get('/my-bookings', [BookingController::class, 'index'])->name('bookings.index');
    Route::patch('/my-bookings/{booking}/cancel', [BookingController::class, 'cancel'])->name('bookings.cancel');
});

Route::middleware(['auth', CheckRole::class.':admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('services', Admin\ServiceController::class)->except('show');
    Route::get('/bookings', [Admin\BookingController::class, 'index'])->name('bookings.index');
    Route::patch('/bookings/{booking}', [Admin\BookingController::class, 'update'])->name('bookings.update');
    Route::get('/blocked', [Admin\BlockedDateController::class, 'index'])->name('blocked.index');
    Route::post('/blocked', [Admin\BlockedDateController::class, 'store'])->name('blocked.store');
    Route::delete('/blocked/{blocked}', [Admin\BlockedDateController::class, 'destroy'])->name('blocked.destroy');
});
