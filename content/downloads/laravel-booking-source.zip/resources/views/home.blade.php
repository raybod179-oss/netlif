<x-layout title="خانه">
<div class="box"><h1>رزرو آنلاین نوبت</h1><p>خدمت را انتخاب کن، روز و ساعت خالی را ببین و در چند ثانیه نوبت بگیر.</p></div>
<div class="grid">@foreach($services as $s)
 <div class="card"><div class="b"><h3>{{ $s->name }}</h3><p class="meta">{{ $s->description }}</p>
 <p>{{ $s->duration }} دقیقه · {{ number_format($s->price) }} تومان</p>
 <a class="btn" href="{{ route('book.create', ['service_id' => $s->id]) }}">رزرو این خدمت</a></div></div>@endforeach</div>
</x-layout>
