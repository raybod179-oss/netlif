@props(['title' => 'پنل مدیریت'])
<x-layout :title="$title">
    <nav class="cats">
        <a href="{{ route('admin.dashboard') }}">داشبورد</a><a href="{{ route('admin.bookings.index') }}">نوبت‌ها</a>
        <a href="{{ route('admin.services.index') }}">خدمات</a><a href="{{ route('admin.blocked.index') }}">روزهای تعطیل</a>
    </nav>
    {{ $slot }}
</x-layout>
