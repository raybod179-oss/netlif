@props(['title' => 'رزرو وقت'])
<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ $title }} | {{ config('booking.name') }}</title><link rel="stylesheet" href="{{ asset('css/booking.css') }}"></head>
<body>
<header class="top"><div class="wrap">
    <a href="{{ route('home') }}"><b>📅 {{ config('booking.name') }}</b></a><span class="sp"></span>
    @auth
        <a href="{{ route('book.create') }}">رزرو نوبت</a><a href="{{ route('bookings.index') }}">نوبت‌های من</a>
        @if(auth()->user()->isAdmin())<a href="{{ route('admin.dashboard') }}">پنل مدیریت</a>@endif
        <form method="post" action="{{ route('logout') }}">@csrf<button class="gray">خروج</button></form>
    @else<a href="{{ route('login') }}">ورود</a><a href="{{ route('register') }}">ثبت‌نام</a>@endauth
</div></header>
<main class="wrap">
    @if(session('success'))<div class="alert ok">{{ session('success') }}</div>@endif
    @if(session('error'))<div class="alert err">{{ session('error') }}</div>@endif
    {{ $slot }}
</main>
<footer>پروژه‌ی سوم دوره‌ی «Laravel از صفر تا ۱۰۰۰» · ساخته‌شده توسط Rayvo — رایبد اکبرلو</footer>
</body></html>
