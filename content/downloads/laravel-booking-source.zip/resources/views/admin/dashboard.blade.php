<x-admin title="داشبورد">
<div class="stats">@foreach($stats as $l => $n)<div class="box"><b>{{ $n }}</b>{{ $l }}</div>@endforeach</div>
<div class="box"><h3>نوبت‌های پیش‌رو</h3><table>@foreach($upcoming as $b)<tr><td>{{ $b->user->name }}</td><td>{{ $b->service->name }}</td><td>{{ $b->date->format('Y/m/d') }} {{ $b->start_time }}</td><td>{{ $b->label() }}</td></tr>@endforeach</table></div>
</x-admin>
