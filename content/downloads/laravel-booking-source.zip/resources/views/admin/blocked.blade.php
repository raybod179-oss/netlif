<x-admin title="روزهای تعطیل">
<form class="box" method="post" action="{{ route('admin.blocked.store') }}" style="display:flex;gap:8px">@csrf<input type="date" name="date" required><input name="reason" placeholder="دلیل (اختیاری)"><button>افزودن</button></form>
@error('date')<div class="fe">{{ $message }}</div>@enderror
<table>@foreach($dates as $d)<tr><td>{{ $d->date->format('Y/m/d') }}</td><td>{{ $d->reason }}</td><td><form method="post" action="{{ route('admin.blocked.destroy', $d) }}">@csrf @method('DELETE')<button class="red">حذف</button></form></td></tr>@endforeach</table>
</x-admin>
