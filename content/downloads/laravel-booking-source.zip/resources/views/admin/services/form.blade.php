<x-admin title="خدمت">
<form class="box" method="post" action="{{ $service->exists ? route('admin.services.update', $service) : route('admin.services.store') }}">@csrf @if($service->exists) @method('PUT') @endif
<label>نام</label><input name="name" value="{{ old('name', $service->name) }}" required>
<label>توضیح</label><textarea name="description" rows="3">{{ old('description', $service->description) }}</textarea>
<label>مدت (دقیقه)</label><input type="number" name="duration" value="{{ old('duration', $service->duration) }}" required>
<label>قیمت (تومان)</label><input type="number" name="price" value="{{ old('price', $service->price) }}" required>
<label style="font-weight:400"><input type="checkbox" name="is_active" value="1" style="width:auto" @checked(old('is_active', $service->is_active))> فعال</label>
@if($errors->any())<div class="alert err">@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>@endif
<p><button>ذخیره</button></p></form></x-admin>
