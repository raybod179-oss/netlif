<x-admin title="خدمات">
<p><a class="btn" href="{{ route('admin.services.create') }}">+ خدمت جدید</a></p>
<table><tr><th>نام</th><th>مدت</th><th>قیمت</th><th>وضعیت</th><th></th></tr>
@foreach($services as $s)<tr><td>{{ $s->name }}</td><td>{{ $s->duration }} دقیقه</td><td>{{ number_format($s->price) }}</td><td>{{ $s->is_active ? 'فعال' : 'غیرفعال' }}</td>
<td style="white-space:nowrap"><a class="btn gray" href="{{ route('admin.services.edit', $s) }}">ویرایش</a>
<form method="post" action="{{ route('admin.services.destroy', $s) }}" style="display:inline" onsubmit="return confirm('حذف شود؟')">@csrf @method('DELETE')<button class="red">حذف</button></form></td></tr>@endforeach</table>
</x-admin>
