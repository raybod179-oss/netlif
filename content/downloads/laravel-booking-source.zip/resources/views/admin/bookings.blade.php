<x-admin title="نوبت‌ها">
<div class="cats"><a href="{{ route('admin.bookings.index') }}">همه</a>@foreach(\App\Models\Booking::STATUSES as $k => $l)<a href="{{ route('admin.bookings.index', ['status' => $k]) }}">{{ $l }}</a>@endforeach</div>
<table><tr><th>کاربر</th><th>خدمت</th><th>زمان</th><th>وضعیت</th></tr>
@foreach($bookings as $b)<tr><td>{{ $b->user->name }}</td><td>{{ $b->service->name }}</td><td>{{ $b->date->format('Y/m/d') }} {{ $b->start_time }}</td>
<td><form method="post" action="{{ route('admin.bookings.update', $b) }}" style="display:flex;gap:6px">@csrf @method('PATCH')
<select name="status">@foreach(\App\Models\Booking::STATUSES as $k => $l)<option value="{{ $k }}" @selected($b->status === $k)>{{ $l }}</option>@endforeach</select><button>ذخیره</button></form></td></tr>@endforeach</table>
@include('partials.pager', ['items' => $bookings])
</x-admin>
