<x-layout title="نوبت‌های من">
<h2>نوبت‌های من</h2>
<table><tr><th>خدمت</th><th>روز</th><th>ساعت</th><th>مبلغ</th><th>وضعیت</th><th></th></tr>
@forelse($bookings as $b)<tr><td>{{ $b->service->name }}</td><td>{{ $b->date->format('Y/m/d') }}</td><td>{{ $b->start_time }} تا {{ $b->end_time }}</td><td>{{ number_format($b->price) }}</td><td>{{ $b->label() }}</td>
<td>@if($b->canCancel())<form method="post" action="{{ route('bookings.cancel', $b) }}" onsubmit="return confirm('لغو شود؟')">@csrf @method('PATCH')<button class="red">لغو</button></form>@endif</td></tr>
@empty<tr><td colspan="6">هنوز نوبتی نگرفته‌ای.</td></tr>@endforelse</table>
@include('partials.pager', ['items' => $bookings])
</x-layout>
