<x-layout title="رزرو نوبت">
<form class="box" method="post" action="{{ route('book.store') }}">@csrf
 <h2>رزرو نوبت</h2>
 <label>خدمت</label>
 <select name="service_id" id="service">@foreach($services as $s)<option value="{{ $s->id }}" @selected(old('service_id', $selected) == $s->id)>{{ $s->name }} ({{ $s->duration }} دقیقه)</option>@endforeach</select>
 <label>روز</label><input type="date" name="date" id="date" min="{{ $min }}" max="{{ $max }}" value="{{ old('date') }}" required>
 <label>ساعت‌های خالی</label><div id="slots" class="slots"></div>
 <input type="hidden" name="start_time" id="start_time" value="{{ old('start_time') }}">
 @error('start_time')<div class="fe">{{ $message }}</div>@enderror
 @error('date')<div class="fe">{{ $message }}</div>@enderror
 <label>توضیح (اختیاری)</label><textarea name="note" rows="2">{{ old('note') }}</textarea>
 <p><button>ثبت نوبت</button></p>
</form>
<script>
const sel = document.getElementById('service'), dt = document.getElementById('date'),
      box = document.getElementById('slots'), inp = document.getElementById('start_time');
async function load() {
  inp.value = ''; box.innerHTML = '';
  if (!sel.value || !dt.value) return;
  const r = await fetch(`{{ route('book.slots') }}?service_id=${sel.value}&date=${dt.value}`, { headers: { Accept: 'application/json' } });
  const data = await r.json();
  if (!data.length) { box.textContent = 'در این روز نوبتی وجود ندارد.'; return; }
  data.forEach(s => {
    const b = document.createElement('button');
    b.type = 'button'; b.textContent = s.start; b.className = 'slot' + (s.free ? '' : ' off'); b.disabled = !s.free;
    b.onclick = () => { inp.value = s.start; box.querySelectorAll('.slot').forEach(x => x.classList.remove('on')); b.classList.add('on'); };
    box.appendChild(b);
  });
}
sel.addEventListener('change', load); dt.addEventListener('change', load); load();
</script>
</x-layout>
