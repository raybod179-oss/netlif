<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Booking extends Model
{
    public const STATUSES = ['pending' => 'در انتظار تأیید', 'confirmed' => 'تأیید شده', 'cancelled' => 'لغو شده', 'done' => 'انجام شده'];
    protected $fillable = ['user_id', 'service_id', 'date', 'start_time', 'end_time', 'price', 'status', 'note'];
    protected function casts(): array { return ['date' => 'date']; }
    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function service(): BelongsTo { return $this->belongsTo(Service::class); }
    public function label(): string { return self::STATUSES[$this->status] ?? $this->status; }
    public function startsAt() { return $this->date->copy()->setTimeFromTimeString($this->start_time); }
    public function canCancel(): bool
    {
        return in_array($this->status, ['pending', 'confirmed'], true)
            && now()->addHours(config('booking.cancel_hours'))->lte($this->startsAt());
    }
}
