<?php
namespace App\Services;
use App\Models\{BlockedDate, Booking, Service};
use Carbon\Carbon;

class SlotService
{
    /** فهرست ساعت‌های یک روز برای یک خدمت: [['start'=>'09:00','end'=>'09:30','free'=>true], ...] */
    public function slots(Service $service, Carbon $date): array
    {
        $date = $date->copy()->startOfDay();
        if ($date->lt(today()) || $date->gt(today()->addDays(config('booking.days_ahead')))) { return []; }
        if (in_array($date->dayOfWeek, config('booking.off_days'), true)) { return []; }
        if (BlockedDate::whereDate('date', $date)->exists()) { return []; }

        $taken = Booking::whereDate('date', $date)->where('status', '!=', 'cancelled')->get(['start_time', 'end_time']);
        $cur = $date->copy()->setTimeFromTimeString(config('booking.open'));
        $close = $date->copy()->setTimeFromTimeString(config('booking.close'));
        $earliest = now()->addMinutes(config('booking.lead_minutes'));
        $out = [];

        while ($cur->copy()->addMinutes($service->duration)->lte($close)) {
            $start = $cur->format('H:i');
            $end = $cur->copy()->addMinutes($service->duration)->format('H:i');
            $free = $cur->gt($earliest) && $taken->every(fn ($b) => ! ($b->start_time < $end && $b->end_time > $start));
            $out[] = ['start' => $start, 'end' => $end, 'free' => $free];
            $cur->addMinutes(config('booking.step'));
        }
        return $out;
    }
}
