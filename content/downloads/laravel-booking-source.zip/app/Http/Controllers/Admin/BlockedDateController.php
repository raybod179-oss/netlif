<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\BlockedDate;
use Illuminate\Http\Request;
class BlockedDateController extends Controller
{
    public function index() { return view('admin.blocked', ['dates' => BlockedDate::orderBy('date')->get()]); }
    public function store(Request $r) { BlockedDate::create($r->validate(['date' => 'required|date|unique:blocked_dates,date', 'reason' => 'nullable|string|max:120'])); return back()->with('success', 'روز تعطیل ثبت شد.'); }
    public function destroy(BlockedDate $blocked) { $blocked->delete(); return back()->with('success', 'حذف شد.'); }
}
