<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\{Booking, Service, User};
class DashboardController extends Controller
{
    public function index()
    {
        return view('admin.dashboard', [
            'stats' => [
                'نوبت‌های امروز' => Booking::whereDate('date', today())->where('status', '!=', 'cancelled')->count(),
                'در انتظار تأیید' => Booking::where('status', 'pending')->count(),
                'خدمات فعال' => Service::where('is_active', true)->count(),
                'کاربران' => User::count(),
            ],
            'upcoming' => Booking::with(['user', 'service'])->whereDate('date', '>=', today())->where('status', '!=', 'cancelled')->orderBy('date')->orderBy('start_time')->limit(8)->get(),
        ]);
    }
}
