<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
class BookingController extends Controller
{
    public function index(Request $request)
    {
        $status = $request->query('status');
        return view('admin.bookings', ['bookings' => Booking::with(['user', 'service'])
            ->when(array_key_exists((string) $status, Booking::STATUSES), fn ($q) => $q->where('status', $status))
            ->orderByDesc('date')->orderByDesc('start_time')->paginate(20)->withQueryString(), 'status' => $status]);
    }
    public function update(Request $request, Booking $booking)
    {
        $booking->update($request->validate(['status' => ['required', Rule::in(array_keys(Booking::STATUSES))]]));
        return back()->with('success', 'وضعیت نوبت به‌روز شد.');
    }
}
