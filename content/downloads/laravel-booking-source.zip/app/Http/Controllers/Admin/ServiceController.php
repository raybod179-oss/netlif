<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Service;
use Illuminate\Http\Request;
class ServiceController extends Controller
{
    private function rules(): array
    {
        return ['name' => 'required|string|max:120', 'description' => 'nullable|string|max:500',
                'duration' => 'required|integer|min:10|max:480', 'price' => 'required|integer|min:0'];
    }
    public function index() { return view('admin.services.index', ['services' => Service::orderBy('name')->get()]); }
    public function create() { return view('admin.services.form', ['service' => new Service(['is_active' => true])]); }
    public function store(Request $r) { Service::create($r->validate($this->rules()) + ['is_active' => $r->boolean('is_active')]); return redirect()->route('admin.services.index')->with('success', 'خدمت ساخته شد.'); }
    public function edit(Service $service) { return view('admin.services.form', compact('service')); }
    public function update(Request $r, Service $service) { $service->update($r->validate($this->rules()) + ['is_active' => $r->boolean('is_active')]); return redirect()->route('admin.services.index')->with('success', 'ویرایش شد.'); }
    public function destroy(Service $service)
    {
        if ($service->id && \App\Models\Booking::where('service_id', $service->id)->exists()) { $service->update(['is_active' => false]); return back()->with('success', 'نوبت دارد؛ فقط غیرفعال شد.'); }
        $service->delete(); return back()->with('success', 'حذف شد.');
    }
}
