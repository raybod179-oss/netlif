<?php
namespace App\Http\Controllers;
use App\Models\{Booking, Service};
use App\Services\SlotService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class BookingController extends Controller
{
    public function create(Request $request)
    {
        return view('booking.create', [
            'services' => Service::where('is_active', true)->orderBy('name')->get(),
            'selected' => $request->integer('service_id'),
            'min' => today()->toDateString(),
            'max' => today()->addDays(config('booking.days_ahead'))->toDateString(),
        ]);
    }

    public function slots(Request $request, SlotService $slots)
    {
        $data = $request->validate(['service_id' => 'required|exists:services,id', 'date' => 'required|date_format:Y-m-d']);
        return response()->json($slots->slots(Service::findOrFail($data['service_id']), Carbon::parse($data['date'])));
    }

    public function store(Request $request, SlotService $slots)
    {
        $data = $request->validate([
            'service_id' => 'required|exists:services,id', 'date' => 'required|date_format:Y-m-d',
            'start_time' => 'required|date_format:H:i', 'note' => 'nullable|string|max:300',
        ]);
        $service = Service::where('is_active', true)->findOrFail($data['service_id']);

        try {
            $booking = DB::transaction(function () use ($request, $data, $service, $slots) {
                $slot = collect($slots->slots($service, Carbon::parse($data['date'])))->firstWhere('start', $data['start_time']);
                if (! $slot || ! $slot['free']) { throw new RuntimeException('این ساعت دیگر خالی نیست. ساعت دیگری انتخاب کنید.'); }
                return Booking::create([
                    'user_id' => $request->user()->id, 'service_id' => $service->id, 'date' => $data['date'],
                    'start_time' => $slot['start'], 'end_time' => $slot['end'], 'price' => $service->price,
                    'note' => $data['note'] ?? null, 'status' => 'pending',
                ]);
            });
        } catch (RuntimeException $e) {
            return back()->withInput()->withErrors(['start_time' => $e->getMessage()]);
        }
        return redirect()->route('bookings.index')->with('success', 'نوبت شما ثبت شد و پس از تأیید قطعی می‌شود.');
    }

    public function index(Request $request)
    {
        return view('booking.index', ['bookings' => $request->user()->bookings()->with('service')->orderByDesc('date')->orderByDesc('start_time')->paginate(10)]);
    }

    public function cancel(Request $request, Booking $booking)
    {
        abort_unless($booking->user_id === $request->user()->id, 403);
        if (! $booking->canCancel()) { return back()->with('error', 'این نوبت دیگر قابل لغو نیست.'); }
        $booking->update(['status' => 'cancelled']);
        return back()->with('success', 'نوبت لغو شد.');
    }
}
