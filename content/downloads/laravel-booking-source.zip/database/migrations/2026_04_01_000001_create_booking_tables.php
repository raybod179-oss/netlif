<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::create('services', function (Blueprint $t) {
            $t->id(); $t->string('name'); $t->text('description')->nullable();
            $t->unsignedSmallInteger('duration');            // دقیقه
            $t->unsignedBigInteger('price')->default(0);
            $t->boolean('is_active')->default(true);
            $t->timestamps();
        });
        Schema::create('bookings', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('service_id')->constrained()->restrictOnDelete();
            $t->date('date')->index();
            $t->string('start_time', 5); $t->string('end_time', 5);
            $t->unsignedBigInteger('price');                  // قیمت لحظه‌ی رزرو
            $t->string('status')->default('pending')->index(); // pending|confirmed|cancelled|done
            $t->string('note', 300)->nullable();
            $t->timestamps();
            $t->unique(['date', 'start_time', 'status']);     // سد اضافه‌ی دیتابیس در برابر رزرو دوباره‌ی همان ساعت
        });
        Schema::create('blocked_dates', function (Blueprint $t) {
            $t->id(); $t->date('date')->unique(); $t->string('reason')->nullable(); $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('blocked_dates'); Schema::dropIfExists('bookings'); Schema::dropIfExists('services'); }
};
