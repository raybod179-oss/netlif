<?php
namespace Database\Seeders;
use App\Models\{Booking, Service, User};
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::forceCreate(['name' => 'مدیر سایت', 'email' => 'admin@book.test', 'password' => Hash::make('password'), 'role' => 'admin']);
        $user = User::forceCreate(['name' => 'کاربر نمونه', 'email' => 'user@book.test', 'password' => Hash::make('password'), 'role' => 'user']);
        $services = collect([['بررسی سریع', 15, 100000], ['مشاوره‌ی ۳۰ دقیقه‌ای', 30, 200000], ['جلسه‌ی ۶۰ دقیقه‌ای', 60, 400000]])
            ->map(fn ($s) => Service::create(['name' => $s[0], 'description' => 'خدمت نمونه؛ از پنل مدیریت ویرایش کن.', 'duration' => $s[1], 'price' => $s[2], 'is_active' => true]));
        Booking::create(['user_id' => $user->id, 'service_id' => $services[1]->id, 'date' => today()->addDay(), 'start_time' => '10:00', 'end_time' => '10:30', 'price' => 200000, 'status' => 'confirmed']);
    }
}
