<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ShopTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User
    {
        return User::factory()->create(['role' => 'admin']);
    }

    public function test_home_and_product_pages_load(): void
    {
        $product = Product::factory()->create();

        $this->get('/')->assertOk()->assertSee($product->name);
        $this->get('/products')->assertOk()->assertSee($product->name);
        $this->get(route('products.show', $product))->assertOk()->assertSee($product->name);
    }

    public function test_inactive_product_is_hidden(): void
    {
        $product = Product::factory()->inactive()->create();

        $this->get(route('products.show', $product))->assertNotFound();
        $this->get('/products')->assertDontSee($product->name);
    }

    public function test_search_filters_products(): void
    {
        Product::factory()->create(['name' => 'کتاب لاراول']);
        Product::factory()->create(['name' => 'ماگ سرامیکی']);

        $this->get('/products?q=لاراول')->assertSee('کتاب لاراول')->assertDontSee('ماگ سرامیکی');
    }

    public function test_guest_is_redirected_from_admin_and_checkout(): void
    {
        $this->get('/admin')->assertRedirect(route('login'));
        $this->get('/checkout')->assertRedirect(route('login'));
    }

    public function test_customer_cannot_open_admin(): void
    {
        $this->actingAs(User::factory()->create())->get('/admin')->assertForbidden();
    }

    public function test_admin_can_open_admin_pages(): void
    {
        $this->actingAs($this->admin());

        $this->get('/admin')->assertOk();
        $this->get('/admin/products')->assertOk();
        $this->get('/admin/categories')->assertOk();
        $this->get('/admin/orders')->assertOk();
    }

    public function test_admin_can_create_category_and_product(): void
    {
        $this->actingAs($this->admin());

        $this->post('/admin/categories', ['name' => 'تست', 'icon' => '🧪'])->assertRedirect(route('admin.categories.index'));
        $category = Category::where('name', 'تست')->firstOrFail();

        $this->post('/admin/products', [
            'category_id' => $category->id,
            'name' => 'محصول تستی',
            'price' => 150000,
            'stock' => 7,
            'is_active' => 1,
        ])->assertRedirect(route('admin.products.index'));

        $this->assertDatabaseHas('products', ['name' => 'محصول تستی', 'stock' => 7]);
    }

    public function test_product_validation_errors(): void
    {
        $this->actingAs($this->admin())
            ->post('/admin/products', ['name' => ''])
            ->assertSessionHasErrors(['name', 'category_id', 'price', 'stock']);
    }

    public function test_cart_and_checkout_create_order_and_reduce_stock(): void
    {
        $product = Product::factory()->create(['price' => 100000, 'stock' => 5]);
        $user = User::factory()->create();

        $this->post(route('cart.store', $product), ['quantity' => 2]);
        $this->get('/cart')->assertOk()->assertSee($product->name);

        $this->actingAs($user)->post('/checkout', [
            'name' => 'علی رضایی',
            'phone' => '09123456789',
            'city' => 'تهران',
            'address' => 'تهران، خیابان آزادی، پلاک ۱۰',
        ])->assertRedirect();

        $order = Order::firstOrFail();
        $this->assertSame(200000, $order->total);
        $this->assertSame($user->id, $order->user_id);
        $this->assertSame(3, $product->fresh()->stock);
        $this->assertDatabaseHas('order_product', ['order_id' => $order->id, 'product_id' => $product->id, 'quantity' => 2, 'price' => 100000]);
    }

    public function test_cannot_add_out_of_stock_product(): void
    {
        $product = Product::factory()->outOfStock()->create();

        $this->post(route('cart.store', $product))->assertSessionHas('error');
        $this->get('/cart')->assertDontSee($product->name);
    }

    public function test_customer_sees_only_own_order(): void
    {
        $owner = User::factory()->create();
        $other = User::factory()->create();
        $order = Order::create([
            'user_id' => $owner->id, 'status' => 'pending', 'total' => 1000,
            'name' => 'x', 'phone' => '09123456789', 'city' => 'تهران', 'address' => 'آدرس نمونه ۱۲۳',
        ]);

        $this->actingAs($owner)->get(route('orders.show', $order))->assertOk();
        $this->actingAs($other)->get(route('orders.show', $order))->assertForbidden();
    }

    public function test_cancelling_order_restores_stock(): void
    {
        $product = Product::factory()->create(['stock' => 5]);
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('cart.store', $product), ['quantity' => 2]);
        $this->post('/checkout', [
            'name' => 'علی', 'phone' => '09123456789', 'city' => 'تهران', 'address' => 'آدرس نمونه ۱۲۳۴۵',
        ]);
        $this->assertSame(3, $product->fresh()->stock);

        $order = Order::firstOrFail();
        $this->actingAs($this->admin())->patch(route('admin.orders.update', $order), ['status' => 'cancelled']);

        $this->assertSame(5, $product->fresh()->stock);
        $this->assertSame('cancelled', $order->fresh()->status);
    }

    public function test_register_login_logout(): void
    {
        $this->post('/register', [
            'name' => 'کاربر', 'email' => 'a@b.test', 'password' => 'secret-pass-1', 'password_confirmation' => 'secret-pass-1',
        ])->assertRedirect(route('home'));
        $this->assertAuthenticated();
        $this->assertSame('customer', User::first()->role);

        $this->post('/logout')->assertRedirect(route('home'));
        $this->assertGuest();

        $this->post('/login', ['email' => 'a@b.test', 'password' => 'wrong'])->assertSessionHasErrors('email');
        $this->post('/login', ['email' => 'a@b.test', 'password' => 'secret-pass-1'])->assertRedirect(route('home'));
    }
}
