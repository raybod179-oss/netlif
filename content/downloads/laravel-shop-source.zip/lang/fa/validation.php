<?php

/*
| ترجمه‌ی فارسیِ قواعد پرکاربرد. قاعده‌ای که این‌جا نباشد، خودکار به انگلیسی (fallback) برمی‌گردد.
*/
return [
    'required' => 'فیلد :attribute الزامی است.',
    'string' => 'فیلد :attribute باید متن باشد.',
    'email' => 'فیلد :attribute باید یک ایمیل معتبر باشد.',
    'unique' => 'این :attribute قبلاً ثبت شده است.',
    'exists' => ':attribute انتخاب‌شده معتبر نیست.',
    'confirmed' => 'تکرار :attribute با مقدار اصلی یکسان نیست.',
    'integer' => 'فیلد :attribute باید عدد صحیح باشد.',
    'boolean' => 'فیلد :attribute نامعتبر است.',
    'in' => ':attribute انتخاب‌شده معتبر نیست.',
    'image' => 'فیلد :attribute باید تصویر باشد.',
    'mimes' => 'فرمت :attribute باید یکی از این‌ها باشد: :values.',
    'regex' => 'قالب فیلد :attribute معتبر نیست.',

    'min' => [
        'numeric' => 'فیلد :attribute باید حداقل :min باشد.',
        'file' => 'حجم :attribute باید حداقل :min کیلوبایت باشد.',
        'string' => 'فیلد :attribute باید حداقل :min کاراکتر باشد.',
    ],
    'max' => [
        'numeric' => 'فیلد :attribute نباید بیشتر از :max باشد.',
        'file' => 'حجم :attribute نباید بیشتر از :max کیلوبایت باشد.',
        'string' => 'فیلد :attribute نباید بیشتر از :max کاراکتر باشد.',
    ],

    'attributes' => [
        'name' => 'نام',
        'email' => 'ایمیل',
        'password' => 'گذرواژه',
    ],
];
