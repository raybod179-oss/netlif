<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Collection;

/**
 * سبد خرید مبتنی بر Session.
 * در سشن فقط  product_id => quantity  نگه می‌داریم؛ قیمت و موجودی همیشه از دیتابیس خوانده می‌شود،
 * تا کاربر نتواند قیمت را دستکاری کند.
 */
class Cart
{
    private const KEY = 'cart';

    private ?Collection $lines = null;

    /** @return array<int,int> */
    private function raw(): array
    {
        return session()->get(self::KEY, []);
    }

    private function save(array $raw): void
    {
        session()->put(self::KEY, $raw);
        $this->lines = null; // کش داخلی را باطل کن
    }

    /** تعداد کل اقلام (برای نشان کنار آیکن سبد؛ بدون کوئری) */
    public function count(): int
    {
        return (int) array_sum($this->raw());
    }

    /**
     * اقلام سبد با اطلاعات تازه از دیتابیس.
     * محصولِ حذف‌شده/غیرفعال/ناموجود از سبد کنار گذاشته می‌شود و تعداد به موجودی محدود می‌شود.
     *
     * @return Collection<int,array{product:Product,quantity:int,subtotal:int}>
     */
    public function items(): Collection
    {
        if ($this->lines !== null) {
            return $this->lines;
        }

        $raw = $this->raw();

        if ($raw === []) {
            return $this->lines = collect();
        }

        $products = Product::query()->active()->whereIn('id', array_keys($raw))->get()->keyBy('id');

        return $this->lines = collect($raw)
            ->map(function (int $qty, int $id) use ($products) {
                $product = $products->get($id);

                if (! $product || $product->stock < 1) {
                    return null;
                }

                $qty = max(1, min($qty, $product->stock, (int) config('shop.max_quantity')));

                return ['product' => $product, 'quantity' => $qty, 'subtotal' => $product->price * $qty];
            })
            ->filter()
            ->values();
    }

    public function total(): int
    {
        return (int) $this->items()->sum('subtotal');
    }

    public function isEmpty(): bool
    {
        return $this->items()->isEmpty();
    }

    public function add(Product $product, int $quantity = 1): void
    {
        $raw = $this->raw();
        $raw[$product->id] = ($raw[$product->id] ?? 0) + $quantity;
        $raw[$product->id] = min($raw[$product->id], $product->stock, (int) config('shop.max_quantity'));
        $this->save($raw);
    }

    public function set(Product $product, int $quantity): void
    {
        $raw = $this->raw();

        if ($quantity < 1) {
            unset($raw[$product->id]);
        } else {
            $raw[$product->id] = min($quantity, $product->stock, (int) config('shop.max_quantity'));
        }

        $this->save($raw);
    }

    public function remove(Product $product): void
    {
        $raw = $this->raw();
        unset($raw[$product->id]);
        $this->save($raw);
    }

    public function clear(): void
    {
        session()->forget(self::KEY);
        $this->lines = null;
    }
}
