<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id', 'status', 'total', 'name', 'phone', 'city', 'address', 'note',
    ];

    protected function casts(): array
    {
        return ['total' => 'integer'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class)->withPivot('quantity', 'price');
    }

    public function statusLabel(): string
    {
        return config('shop.order_statuses')[$this->status] ?? $this->status;
    }

    public function isCancelled(): bool
    {
        return $this->status === 'cancelled';
    }
}
