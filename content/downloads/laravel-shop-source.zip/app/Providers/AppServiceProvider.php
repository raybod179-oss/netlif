<?php

namespace App\Providers;

use App\Services\Cart;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // یک نمونه‌ی مشترک از سبد در طول هر درخواست (کوئری تکراری نمی‌زند)
        $this->app->scoped(Cart::class);
    }

    public function boot(): void
    {
        app()->setLocale(config('shop.locale'));

        // قالب صفحه‌بندی فارسی و بدون وابستگی به Tailwind
        Paginator::defaultView('vendor.pagination.shop');
        Paginator::defaultSimpleView('vendor.pagination.shop');
    }
}
