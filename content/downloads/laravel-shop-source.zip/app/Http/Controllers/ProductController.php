<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request): View
    {
        $request->validate([
            'q' => ['nullable', 'string', 'max:100'],
            'category' => ['nullable', 'integer'],
            'sort' => ['nullable', 'in:newest,cheapest,expensive'],
        ]);

        $products = Product::query()
            ->active()
            ->with('category')
            ->when($request->filled('q'), fn ($q) => $q->where('name', 'like', '%'.$request->string('q').'%'))
            ->when($request->filled('category'), fn ($q) => $q->where('category_id', $request->integer('category')))
            ->when($request->input('sort') === 'cheapest', fn ($q) => $q->orderBy('price'))
            ->when($request->input('sort') === 'expensive', fn ($q) => $q->orderByDesc('price'))
            ->when(! in_array($request->input('sort'), ['cheapest', 'expensive'], true), fn ($q) => $q->latest('id'))
            ->paginate(config('shop.per_page'))
            ->withQueryString();

        return view('products.index', [
            'products' => $products,
            'categories' => Category::query()->withCount(['products' => fn ($q) => $q->active()])->orderBy('name')->get(),
        ]);
    }

    public function show(Product $product): View
    {
        abort_unless($product->is_active, 404);

        $product->load('category');

        $related = Product::query()
            ->active()
            ->where('category_id', $product->category_id)
            ->whereKeyNot($product->id)
            ->inRandomOrder()
            ->take(4)
            ->get();

        return view('products.show', compact('product', 'related'));
    }
}
