<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Services\Cart;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index(Cart $cart): View
    {
        return view('cart.index', [
            'items' => $cart->items(),
            'total' => $cart->total(),
        ]);
    }

    public function store(Request $request, Product $product, Cart $cart): RedirectResponse
    {
        abort_unless($product->is_active, 404);

        $data = $request->validate([
            'quantity' => ['nullable', 'integer', 'min:1', 'max:'.config('shop.max_quantity')],
        ]);

        if (! $product->inStock()) {
            return back()->with('error', "«{$product->name}» فعلاً ناموجود است.");
        }

        $cart->add($product, $data['quantity'] ?? 1);

        return back()->with('success', "«{$product->name}» به سبد خرید اضافه شد.");
    }

    public function update(Request $request, Product $product, Cart $cart): RedirectResponse
    {
        $data = $request->validate([
            'quantity' => ['required', 'integer', 'min:0', 'max:'.config('shop.max_quantity')],
        ]);

        $cart->set($product, $data['quantity']);

        return redirect()->route('cart.index')->with('success', 'سبد خرید به‌روز شد.');
    }

    public function destroy(Product $product, Cart $cart): RedirectResponse
    {
        $cart->remove($product);

        return redirect()->route('cart.index')->with('success', 'محصول از سبد حذف شد.');
    }

    public function clear(Cart $cart): RedirectResponse
    {
        $cart->clear();

        return redirect()->route('cart.index')->with('success', 'سبد خرید خالی شد.');
    }
}
