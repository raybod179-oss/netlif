<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Contracts\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        return view('admin.dashboard', [
            'stats' => [
                'products' => Product::count(),
                'categories' => Category::count(),
                'orders' => Order::count(),
                'customers' => User::where('role', 'customer')->count(),
                'revenue' => (int) Order::where('status', '!=', 'cancelled')->sum('total'),
            ],
            'latestOrders' => Order::with('user')->latest('id')->take(6)->get(),
            'lowStock' => Product::where('stock', '<=', config('shop.low_stock'))->orderBy('stock')->take(6)->get(),
        ]);
    }
}
