<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function index(Request $request): View
    {
        $statuses = array_keys(config('shop.order_statuses'));

        $orders = Order::query()
            ->with('user')
            ->withCount('products')
            ->when(in_array($request->input('status'), $statuses, true), fn ($q) => $q->where('status', $request->input('status')))
            ->latest('id')
            ->paginate(config('shop.admin_per_page'))
            ->withQueryString();

        return view('admin.orders.index', compact('orders'));
    }

    public function show(Order $order): View
    {
        $order->load(['user', 'products']);

        return view('admin.orders.show', compact('order'));
    }

    public function update(Request $request, Order $order): RedirectResponse
    {
        $data = $request->validate([
            'status' => ['required', Rule::in(array_keys(config('shop.order_statuses')))],
        ]);

        if ($order->isCancelled()) {
            return back()->with('error', 'سفارشِ لغوشده قابل تغییر نیست.');
        }

        DB::transaction(function () use ($order, $data) {
            // لغو سفارش = برگرداندن موجودی به انبار
            if ($data['status'] === 'cancelled') {
                foreach ($order->products as $product) {
                    $product->increment('stock', $product->pivot->quantity);
                }
            }

            $order->update(['status' => $data['status']]);
        });

        return back()->with('success', 'وضعیت سفارش به‌روز شد.');
    }
}
