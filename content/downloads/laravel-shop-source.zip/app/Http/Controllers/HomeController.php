<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Contracts\View\View;

class HomeController extends Controller
{
    public function __invoke(): View
    {
        return view('home', [
            'categories' => Category::query()->withCount(['products' => fn ($q) => $q->active()])->orderBy('name')->get(),
            'latest' => Product::query()->active()->with('category')->latest()->take(8)->get(),
        ]);
    }
}
