<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CheckoutRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:100'],
            'phone' => ['required', 'string', 'regex:/^(\+98|0)?9\d{9}$/'],
            'city' => ['required', 'string', 'max:100'],
            'address' => ['required', 'string', 'min:10', 'max:1000'],
            'note' => ['nullable', 'string', 'max:500'],
        ];
    }

    public function messages(): array
    {
        return ['phone.regex' => 'شماره موبایل معتبر نیست (مثال: 09123456789).'];
    }

    public function attributes(): array
    {
        return [
            'name' => 'نام و نام خانوادگی',
            'phone' => 'شماره موبایل',
            'city' => 'شهر',
            'address' => 'آدرس',
            'note' => 'توضیحات',
        ];
    }
}
