<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CategoryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => [
                'required', 'string', 'max:100',
                Rule::unique('categories', 'name')->ignore($this->route('category')),
            ],
            'icon' => ['nullable', 'string', 'max:8'],
        ];
    }

    public function attributes(): array
    {
        return ['name' => 'نام دسته‌بندی', 'icon' => 'آیکن'];
    }
}
