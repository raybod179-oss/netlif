<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * استفاده در روت:  CheckRole::class.':admin'
 * نکته: این میان‌افزار باید «بعد از» auth بیاید، چون به کاربر لاگین‌کرده نیاز دارد.
 */
class CheckRole
{
    public function handle(Request $request, Closure $next, string $role): Response
    {
        $user = $request->user();

        abort_unless($user && $user->role === $role, 403, 'دسترسی به این بخش برای شما مجاز نیست.');

        return $next($request);
    }
}
