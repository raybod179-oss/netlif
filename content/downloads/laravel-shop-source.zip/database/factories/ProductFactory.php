<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

/** @extends Factory<Product> */
class ProductFactory extends Factory
{
    public function definition(): array
    {
        return [
            'category_id' => Category::factory(),
            'name' => 'محصول '.fake()->unique()->numberBetween(1, 99999),
            'description' => 'توضیحات نمونه برای محصول آزمایشی.',
            'price' => fake()->numberBetween(20, 900) * 1000,
            'stock' => fake()->numberBetween(5, 50),
            'image' => null,
            'is_active' => true,
        ];
    }

    public function outOfStock(): static
    {
        return $this->state(['stock' => 0]);
    }

    public function inactive(): static
    {
        return $this->state(['is_active' => false]);
    }
}
