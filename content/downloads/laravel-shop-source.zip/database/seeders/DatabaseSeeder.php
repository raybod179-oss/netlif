<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // role عمداً fillable نیست، پس برای حساب‌های اولیه از forceFill استفاده می‌کنیم.
        foreach ([
            ['email' => 'admin@shop.test', 'name' => 'مدیر فروشگاه', 'role' => 'admin'],
            ['email' => 'customer@shop.test', 'name' => 'مشتری نمونه', 'role' => 'customer'],
        ] as $account) {
            $user = User::firstOrNew(['email' => $account['email']]);
            $user->forceFill([
                'name' => $account['name'],
                'role' => $account['role'],
                'password' => 'password',
                'email_verified_at' => now(),
            ])->save();
        }

        $this->call([
            CategorySeeder::class,
            ProductSeeder::class,
            OrderSeeder::class,
        ]);
    }
}
