<?php

namespace Database\Seeders;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Seeder;

/** چند سفارش نمونه تا داشبورد مدیر خالی نباشد (موجودی کم نمی‌شود؛ فقط دمو است). */
class OrderSeeder extends Seeder
{
    public function run(): void
    {
        $customer = User::where('email', 'customer@shop.test')->first();

        if (! $customer || Order::exists()) {
            return;
        }

        $products = Product::active()->where('stock', '>', 0)->inRandomOrder()->take(12)->get();

        foreach (['completed', 'shipped', 'processing', 'pending'] as $i => $status) {
            $picked = $products->slice($i * 2, 2);
            $total = $picked->sum(fn ($p) => $p->price * ($i + 1));

            $order = Order::create([
                'user_id' => $customer->id,
                'status' => $status,
                'total' => $total,
                'name' => $customer->name,
                'phone' => '09123456789',
                'city' => 'تهران',
                'address' => 'تهران، خیابان نمونه، پلاک ۱۲، واحد ۳',
            ]);

            foreach ($picked as $product) {
                $order->products()->attach($product->id, ['quantity' => $i + 1, 'price' => $product->price]);
            }
        }
    }
}
