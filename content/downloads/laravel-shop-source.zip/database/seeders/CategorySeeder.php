<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        foreach ([
            ['name' => 'کتاب', 'icon' => '📚'],
            ['name' => 'نوشت‌افزار', 'icon' => '✏️'],
            ['name' => 'لوازم دیجیتال', 'icon' => '🎧'],
            ['name' => 'خانه و آشپزخانه', 'icon' => '☕'],
            ['name' => 'ورزش و سفر', 'icon' => '🎒'],
        ] as $row) {
            Category::updateOrCreate(['name' => $row['name']], $row);
        }
    }
}
