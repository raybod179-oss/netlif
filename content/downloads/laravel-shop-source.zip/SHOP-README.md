# فروشگاه لاراول — سورس پروژه‌ی دوره

این بسته فقط «فایل‌های فروشگاه» است و باید روی یک پروژه‌ی تازه‌ی Laravel (نسخه ۱۲ یا ۱۳) کپی شود.

## نصب سریع

```bash
composer create-project laravel/laravel laravel-shop
cd laravel-shop
# محتوای zip را داخل همین پوشه استخراج کن (فایل‌های هم‌نام را Replace کن)
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

سپس `http://127.0.0.1:8000` را باز کن.

## حساب‌های آزمایشی

| نقش   | ایمیل              | گذرواژه  |
|-------|--------------------|----------|
| مدیر  | admin@shop.test    | password |
| مشتری | customer@shop.test | password |

پنل مدیریت: `/admin`

## اجرای تست‌ها

```bash
php artisan test
```

## امکانات

- فهرست محصولات با جستجو، فیلتر دسته، مرتب‌سازی و صفحه‌بندی
- سبد خرید مبتنی بر Session (قیمت و موجودی همیشه از دیتابیس)
- ثبت سفارش داخل تراکنش دیتابیس + کم‌شدن موجودی + ذخیره‌ی قیمت لحظه‌ی خرید
- ثبت‌نام / ورود / خروج با محدودیت تعداد تلاش
- پنل مدیریت: داشبورد، CRUD دسته‌بندی و محصول (با آپلود تصویر)، مدیریت وضعیت سفارش (لغو = برگشت موجودی)
- Policy برای سفارش‌ها، میان‌افزار نقش، Form Request، Service برای سبد
- ظاهر فارسی راست‌به‌چپ بدون نیاز به npm

## فایل‌هایی که روی پروژه‌ی شما بازنویسی می‌شوند

`routes/web.php` ، `app/Models/User.php` ، `app/Providers/AppServiceProvider.php` ، `database/seeders/DatabaseSeeder.php`
