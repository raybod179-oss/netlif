<x-layout title="سفارش‌های من">
    <h1 class="mt">سفارش‌های من</h1>

    @if ($orders->isEmpty())
        <div class="empty card">هنوز سفارشی ثبت نکرده‌اید. <a href="{{ route('products.index') }}">شروع خرید</a></div>
    @else
        <div class="card table-wrap">
            <table>
                <thead><tr><th>شماره</th><th>تاریخ</th><th>اقلام</th><th>مبلغ</th><th>وضعیت</th><th></th></tr></thead>
                <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>#{{ $order->id }}</td>
                        <td>{{ $order->created_at->format('Y/m/d H:i') }}</td>
                        <td>{{ $order->products_count }}</td>
                        <td><x-price :value="$order->total" /></td>
                        <td><x-order-status :order="$order" /></td>
                        <td><a class="btn secondary sm" href="{{ route('orders.show', $order) }}">جزئیات</a></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        {{ $orders->links() }}
    @endif
</x-layout>
