<x-layout :title="'سفارش #'.$order->id">
    <h1 class="mt">سفارش #{{ $order->id }} <x-order-status :order="$order" /></h1>

    <div class="cols-2">
        <div class="card table-wrap">
            <table>
                <thead><tr><th>محصول</th><th>قیمت</th><th>تعداد</th><th>جمع</th></tr></thead>
                <tbody>
                @foreach ($order->products as $product)
                    <tr>
                        <td>{{ $product->name }}</td>
                        <td><x-price :value="$product->pivot->price" /></td>
                        <td>{{ $product->pivot->quantity }}</td>
                        <td><x-price :value="$product->pivot->price * $product->pivot->quantity" /></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <p class="row between mt"><strong>جمع کل</strong><x-price :value="$order->total" /></p>
        </div>

        <div class="card">
            <h3>مشخصات گیرنده</h3>
            <p>{{ $order->name }}<br><span class="ltr">{{ $order->phone }}</span></p>
            <p>{{ $order->city }}، {{ $order->address }}</p>
            @if ($order->note)<p class="muted">توضیحات: {{ $order->note }}</p>@endif
            <p class="muted small">ثبت‌شده در {{ $order->created_at->format('Y/m/d H:i') }}</p>
            <a class="btn secondary" href="{{ route('orders.index') }}">همه‌ی سفارش‌ها</a>
        </div>
    </div>
</x-layout>
