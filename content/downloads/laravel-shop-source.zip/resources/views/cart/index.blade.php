<x-layout title="سبد خرید">
    <h1 class="mt">سبد خرید</h1>

    @if ($items->isEmpty())
        <div class="empty card">
            <p>سبد خرید شما خالی است.</p>
            <a class="btn" href="{{ route('products.index') }}">رفتن به فروشگاه</a>
        </div>
    @else
        <div class="card table-wrap">
            <table>
                <thead>
                    <tr><th>محصول</th><th>قیمت واحد</th><th>تعداد</th><th>جمع</th><th></th></tr>
                </thead>
                <tbody>
                @foreach ($items as $line)
                    @php($product = $line['product'])
                    <tr>
                        <td><a href="{{ route('products.show', $product) }}">{{ $product->name }}</a></td>
                        <td><x-price :value="$product->price" /></td>
                        <td>
                            <form method="POST" action="{{ route('cart.update', $product) }}" class="row">
                                @csrf
                                @method('PATCH')
                                <input class="qty" type="number" name="quantity" value="{{ $line['quantity'] }}" min="0"
                                       max="{{ min($product->stock, config('shop.max_quantity')) }}" aria-label="تعداد">
                                <button class="btn secondary sm" type="submit">به‌روزرسانی</button>
                            </form>
                        </td>
                        <td><x-price :value="$line['subtotal']" /></td>
                        <td>
                            <form method="POST" action="{{ route('cart.destroy', $product) }}">
                                @csrf
                                @method('DELETE')
                                <button class="btn danger sm" type="submit">حذف</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

        <div class="row between mt">
            <form method="POST" action="{{ route('cart.clear') }}" onsubmit="return confirm('سبد خرید خالی شود؟')">
                @csrf
                @method('DELETE')
                <button class="btn secondary" type="submit">خالی کردن سبد</button>
            </form>

            <div class="row">
                <span>جمع کل: <x-price :value="$total" /></span>
                <a class="btn" href="{{ route('checkout.create') }}">ادامه و ثبت سفارش</a>
            </div>
        </div>
    @endif
</x-layout>
