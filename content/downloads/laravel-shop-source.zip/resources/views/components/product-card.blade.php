@props(['product'])
<article class="product-card">
    <a href="{{ route('products.show', $product) }}" aria-label="{{ $product->name }}">
        <x-product-image :product="$product" />
    </a>
    <div class="body">
        <span class="tag">{{ $product->category->name }}</span>
        <a class="name" href="{{ route('products.show', $product) }}">{{ $product->name }}</a>

        <div class="foot">
            <x-price :value="$product->price" />
            @if ($product->inStock())
                <form method="POST" action="{{ route('cart.store', $product) }}">
                    @csrf
                    <button class="btn sm" type="submit">افزودن</button>
                </form>
            @else
                <span class="tag danger">ناموجود</span>
            @endif
        </div>
    </div>
</article>
