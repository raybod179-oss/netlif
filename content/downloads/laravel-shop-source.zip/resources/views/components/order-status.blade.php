@props(['order'])
@php
    $class = match ($order->status) {
        'completed' => 'ok',
        'cancelled' => 'danger',
        'pending' => 'warn',
        default => '',
    };
@endphp
<span class="tag {{ $class }}">{{ $order->statusLabel() }}</span>
