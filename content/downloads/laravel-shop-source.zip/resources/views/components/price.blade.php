@props(['value'])
<span class="price">{{ number_format($value) }} <small>{{ config('shop.currency') }}</small></span>
