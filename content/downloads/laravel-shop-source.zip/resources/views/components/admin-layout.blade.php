@props(['title' => 'مدیریت'])
<x-layout :title="$title">
    <div class="admin-wrap">
        <aside class="admin-side" aria-label="منوی مدیریت">
            <a href="{{ route('admin.dashboard') }}" @class(['active' => request()->routeIs('admin.dashboard')])>📊 داشبورد</a>
            <a href="{{ route('admin.products.index') }}" @class(['active' => request()->routeIs('admin.products.*')])>📦 محصولات</a>
            <a href="{{ route('admin.categories.index') }}" @class(['active' => request()->routeIs('admin.categories.*')])>🗂️ دسته‌بندی‌ها</a>
            <a href="{{ route('admin.orders.index') }}" @class(['active' => request()->routeIs('admin.orders.*')])>🧾 سفارش‌ها</a>
            <a href="{{ route('home') }}">↩ مشاهده‌ی فروشگاه</a>
        </aside>
        <section>
            <h1>{{ $title }}</h1>
            {{ $slot }}
        </section>
    </div>
</x-layout>
