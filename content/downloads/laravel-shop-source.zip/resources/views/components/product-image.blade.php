@props(['product', 'large' => false])
<div @class(['thumb', 'lg' => $large])>
    @if ($product->image)
        <img src="{{ asset('storage/'.$product->image) }}" alt="{{ $product->name }}" loading="lazy">
    @else
        <span aria-hidden="true">{{ $product->category->icon ?? '📦' }}</span>
    @endif
</div>
