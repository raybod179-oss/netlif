@props(['name', 'label', 'type' => 'text', 'value' => null, 'hint' => null])
<div class="field">
    <label for="{{ $name }}">{{ $label }}</label>
    <input id="{{ $name }}" name="{{ $name }}" type="{{ $type }}"
           value="{{ $type === 'password' ? '' : old($name, $value) }}"
           {{ $attributes->class(['is-invalid' => $errors->has($name)]) }}>
    @if ($hint)<small class="hint">{{ $hint }}</small>@endif
    @error($name)<small class="error">{{ $message }}</small>@enderror
</div>
