@if (session('success'))
    <div class="alert success" role="status">{{ session('success') }}</div>
@endif
@if (session('error'))
    <div class="alert error" role="alert">{{ session('error') }}</div>
@endif
