<x-layout title="خانه">
    <section class="hero">
        <h1>به {{ config('shop.name') }} خوش آمدید</h1>
        <p>کتاب، نوشت‌افزار و لوازم دیجیتال با قیمت مناسب. ثبت‌نام کنید، سبد خرید بسازید و سفارش بدهید.</p>
        <a class="btn" href="{{ route('products.index') }}">مشاهده‌ی همه‌ی محصولات</a>
    </section>

    <h2>دسته‌بندی‌ها</h2>
    <div class="grid cats mb">
        @foreach ($categories as $category)
            <a class="cat-tile" href="{{ route('products.index', ['category' => $category->id]) }}">
                <span class="ic">{{ $category->icon ?? '📦' }}</span>
                <strong>{{ $category->name }}</strong>
                <small class="muted">{{ $category->products_count }} محصول</small>
            </a>
        @endforeach
    </div>

    <h2>تازه‌ترین محصولات</h2>
    @if ($latest->isEmpty())
        <div class="empty">هنوز محصولی ثبت نشده است. <code>php artisan db:seed</code> را اجرا کنید.</div>
    @else
        <div class="grid products">
            @foreach ($latest as $product)
                <x-product-card :product="$product" />
            @endforeach
        </div>
    @endif
</x-layout>
