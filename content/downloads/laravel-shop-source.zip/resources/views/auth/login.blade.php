<x-layout title="ورود">
    <div class="card mt" style="max-width:440px;margin-inline:auto">
        <h1>ورود به حساب</h1>
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <x-field name="email" label="ایمیل" type="email" class="ltr" required autofocus />
            <x-field name="password" label="گذرواژه" type="password" class="ltr" required />
            <label class="check"><input type="checkbox" name="remember" value="1"> مرا به خاطر بسپار</label>
            <button class="btn block" type="submit">ورود</button>
        </form>
        <p class="muted small mt">حساب ندارید؟ <a href="{{ route('register') }}">ثبت‌نام کنید</a></p>
        <p class="muted small">حساب‌های آزمایشی: <span class="ltr">admin@shop.test</span> و <span class="ltr">customer@shop.test</span> با گذرواژه‌ی <code>password</code></p>
    </div>
</x-layout>
