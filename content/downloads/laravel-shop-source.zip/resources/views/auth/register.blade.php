<x-layout title="ثبت‌نام">
    <div class="card mt" style="max-width:440px;margin-inline:auto">
        <h1>ثبت‌نام</h1>
        <form method="POST" action="{{ route('register') }}">
            @csrf
            <x-field name="name" label="نام و نام خانوادگی" required autofocus />
            <x-field name="email" label="ایمیل" type="email" class="ltr" required />
            <x-field name="password" label="گذرواژه" type="password" class="ltr" hint="حداقل ۸ کاراکتر" required />
            <x-field name="password_confirmation" label="تکرار گذرواژه" type="password" class="ltr" required />
            <button class="btn block" type="submit">ساخت حساب</button>
        </form>
        <p class="muted small mt">قبلاً ثبت‌نام کرده‌اید؟ <a href="{{ route('login') }}">ورود</a></p>
    </div>
</x-layout>
