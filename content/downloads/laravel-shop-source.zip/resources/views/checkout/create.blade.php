<x-layout title="ثبت سفارش">
    <h1 class="mt">ثبت سفارش</h1>

    <div class="cols-2">
        <form class="card" method="POST" action="{{ route('checkout.store') }}">
            @csrf
            <h3>مشخصات گیرنده</h3>
            <x-field name="name" label="نام و نام خانوادگی" :value="auth()->user()->name" required />
            <x-field name="phone" label="شماره موبایل" type="tel" class="ltr" placeholder="09123456789" required />
            <x-field name="city" label="شهر" required />

            <div class="field">
                <label for="address">آدرس کامل</label>
                <textarea id="address" name="address" @class(['is-invalid' => $errors->has('address')]) required>{{ old('address') }}</textarea>
                @error('address')<small class="error">{{ $message }}</small>@enderror
            </div>

            <div class="field">
                <label for="note">توضیحات (اختیاری)</label>
                <textarea id="note" name="note">{{ old('note') }}</textarea>
                @error('note')<small class="error">{{ $message }}</small>@enderror
            </div>

            <p class="muted small">پرداخت در این نسخه‌ی آموزشی «در محل تحویل» است؛ درگاه پرداخت واقعی به‌عنوان تمرین پیشنهاد شده است.</p>
            <button class="btn block" type="submit">ثبت نهایی سفارش</button>
        </form>

        <div class="card">
            <h3>خلاصه‌ی سفارش</h3>
            <ul class="side-list">
                @foreach ($items as $line)
                    <li><a href="{{ route('products.show', $line['product']) }}"><span>{{ $line['product']->name }} × {{ $line['quantity'] }}</span><x-price :value="$line['subtotal']" /></a></li>
                @endforeach
            </ul>
            <hr>
            <p class="row between"><strong>جمع کل</strong><x-price :value="$total" /></p>
            <a class="btn secondary block" href="{{ route('cart.index') }}">بازگشت به سبد خرید</a>
        </div>
    </div>
</x-layout>
