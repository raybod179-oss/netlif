<x-layout title="محصولات">
    <h1 class="mt">محصولات</h1>

    <div class="two-col">
        <aside class="card">
            <h3>دسته‌بندی</h3>
            <ul class="side-list">
                <li><a href="{{ route('products.index', request()->except('category', 'page')) }}" @class(['active' => ! request('category')])>همه</a></li>
                @foreach ($categories as $category)
                    <li>
                        <a href="{{ route('products.index', array_merge(request()->except('page'), ['category' => $category->id])) }}"
                           @class(['active' => (int) request('category') === $category->id])>
                            <span>{{ $category->icon }} {{ $category->name }}</span>
                            <small class="muted">{{ $category->products_count }}</small>
                        </a>
                    </li>
                @endforeach
            </ul>

            <form method="GET" action="{{ route('products.index') }}" class="mt">
                @if (request('category'))<input type="hidden" name="category" value="{{ request('category') }}">@endif
                <div class="field">
                    <label for="q">جستجو</label>
                    <input id="q" type="search" name="q" value="{{ request('q') }}">
                </div>
                <div class="field">
                    <label for="sort">مرتب‌سازی</label>
                    <select id="sort" name="sort">
                        <option value="newest" @selected(request('sort', 'newest') === 'newest')>جدیدترین</option>
                        <option value="cheapest" @selected(request('sort') === 'cheapest')>ارزان‌ترین</option>
                        <option value="expensive" @selected(request('sort') === 'expensive')>گران‌ترین</option>
                    </select>
                </div>
                <button class="btn block" type="submit">اعمال</button>
            </form>
        </aside>

        <section>
            @if ($products->isEmpty())
                <div class="empty card">محصولی با این مشخصات پیدا نشد.</div>
            @else
                <p class="muted small">نمایش {{ $products->firstItem() }} تا {{ $products->lastItem() }} از {{ $products->total() }} محصول</p>
                <div class="grid products">
                    @foreach ($products as $product)
                        <x-product-card :product="$product" />
                    @endforeach
                </div>
                {{ $products->links() }}
            @endif
        </section>
    </div>
</x-layout>
