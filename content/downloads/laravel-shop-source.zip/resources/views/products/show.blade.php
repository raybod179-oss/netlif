<x-layout :title="$product->name">
    <p class="muted small mt">
        <a href="{{ route('home') }}">خانه</a> ›
        <a href="{{ route('products.index', ['category' => $product->category_id]) }}">{{ $product->category->name }}</a> ›
        {{ $product->name }}
    </p>

    <div class="cols-2">
        <x-product-image :product="$product" :large="true" />

        <div class="card">
            <span class="tag">{{ $product->category->name }}</span>
            <h1 class="mt">{{ $product->name }}</h1>

            <p><x-price :value="$product->price" /></p>

            @if ($product->inStock())
                <p>
                    @if ($product->isLowStock())
                        <span class="tag warn">فقط {{ $product->stock }} عدد باقی مانده</span>
                    @else
                        <span class="tag ok">موجود</span>
                    @endif
                </p>

                <form method="POST" action="{{ route('cart.store', $product) }}" class="row">
                    @csrf
                    <input class="qty" type="number" name="quantity" value="1" min="1"
                           max="{{ min($product->stock, config('shop.max_quantity')) }}" aria-label="تعداد">
                    <button class="btn" type="submit">افزودن به سبد خرید</button>
                </form>
                @error('quantity')<small class="muted" style="color:var(--danger)">{{ $message }}</small>@enderror
            @else
                <p><span class="tag danger">ناموجود</span></p>
            @endif

            @if ($product->description)
                <h3 class="mt">توضیحات</h3>
                <p>{{ $product->description }}</p>
            @endif
        </div>
    </div>

    @if ($related->isNotEmpty())
        <h2 class="mt">محصولات مرتبط</h2>
        <div class="grid products">
            @foreach ($related as $item)
                <x-product-card :product="$item->setRelation('category', $product->category)" />
            @endforeach
        </div>
    @endif
</x-layout>
