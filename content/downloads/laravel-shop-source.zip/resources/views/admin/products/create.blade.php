<x-admin-layout title="محصول جدید">
    <form class="card" method="POST" action="{{ route('admin.products.store') }}" enctype="multipart/form-data">
        @include('admin.products._form')
    </form>
</x-admin-layout>
