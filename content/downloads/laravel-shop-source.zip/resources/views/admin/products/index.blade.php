<x-admin-layout title="محصولات">
    <div class="row between mb">
        <a class="btn" href="{{ route('admin.products.create') }}">+ محصول جدید</a>
        <form class="row" method="GET" action="{{ route('admin.products.index') }}">
            <input type="search" name="q" value="{{ request('q') }}" placeholder="جستجوی نام…" style="width:220px">
            <button class="btn secondary" type="submit">جستجو</button>
        </form>
    </div>

    <div class="card table-wrap">
        <table>
            <thead><tr><th>تصویر</th><th>نام</th><th>دسته</th><th>قیمت</th><th>موجودی</th><th>وضعیت</th><th></th></tr></thead>
            <tbody>
            @forelse ($products as $product)
                <tr>
                    <td><div class="thumb-sm">@if ($product->image)<img src="{{ asset('storage/'.$product->image) }}" alt="">@else{{ $product->category->icon }}@endif</div></td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->category->name }}</td>
                    <td><x-price :value="$product->price" /></td>
                    <td>{{ $product->stock }}</td>
                    <td>@if ($product->is_active)<span class="tag ok">فعال</span>@else<span class="tag">غیرفعال</span>@endif</td>
                    <td class="row">
                        <a class="btn secondary sm" href="{{ route('admin.products.edit', $product) }}">ویرایش</a>
                        <form method="POST" action="{{ route('admin.products.destroy', $product) }}" onsubmit="return confirm('این محصول حذف شود؟')">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger sm" type="submit">حذف</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">محصولی پیدا نشد.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    {{ $products->links() }}
</x-admin-layout>
