<x-admin-layout title="ویرایش محصول">
    <form class="card" method="POST" action="{{ route('admin.products.update', $product) }}" enctype="multipart/form-data">
        @method('PUT')
        @include('admin.products._form')
    </form>
</x-admin-layout>
