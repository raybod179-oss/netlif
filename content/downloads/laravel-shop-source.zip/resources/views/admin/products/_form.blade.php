@csrf
<div class="field">
    <label for="category_id">دسته‌بندی</label>
    <select id="category_id" name="category_id" @class(['is-invalid' => $errors->has('category_id')]) required>
        <option value="">— انتخاب کنید —</option>
        @foreach ($categories as $category)
            <option value="{{ $category->id }}" @selected((int) old('category_id', $product->category_id ?? null) === $category->id)>{{ $category->name }}</option>
        @endforeach
    </select>
    @error('category_id')<small class="error">{{ $message }}</small>@enderror
</div>

<x-field name="name" label="نام محصول" :value="$product->name ?? null" required />

<div class="field">
    <label for="description">توضیحات</label>
    <textarea id="description" name="description">{{ old('description', $product->description ?? '') }}</textarea>
    @error('description')<small class="error">{{ $message }}</small>@enderror
</div>

<div class="cols-2">
    <x-field name="price" :label="'قیمت ('.config('shop.currency').')'" type="number" :value="$product->price ?? null" min="0" required />
    <x-field name="stock" label="موجودی" type="number" :value="$product->stock ?? 0" min="0" required />
</div>

<div class="field">
    <label for="image">تصویر (jpg / png / webp، حداکثر ۲ مگابایت)</label>
    <input id="image" type="file" name="image" accept="image/*" @class(['is-invalid' => $errors->has('image')])>
    @error('image')<small class="error">{{ $message }}</small>@enderror

    @if (! empty($product?->image))
        <div class="row mt">
            <div class="thumb-sm" style="width:64px;height:64px"><img src="{{ asset('storage/'.$product->image) }}" alt=""></div>
            <label class="check"><input type="checkbox" name="remove_image" value="1"> حذف تصویر فعلی</label>
        </div>
    @endif
</div>

<input type="hidden" name="is_active" value="0">
<label class="check">
    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $product->is_active ?? true))>
    فعال (در فروشگاه نمایش داده شود)
</label>

<button class="btn" type="submit">ذخیره</button>
<a class="btn secondary" href="{{ route('admin.products.index') }}">انصراف</a>
