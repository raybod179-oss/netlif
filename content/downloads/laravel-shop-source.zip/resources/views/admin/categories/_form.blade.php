@csrf
<x-field name="name" label="نام دسته‌بندی" :value="$category->name ?? null" required />
<x-field name="icon" label="آیکن (یک ایموجی)" :value="$category->icon ?? null" hint="مثلاً 📚 — برای محصولاتِ بدون تصویر نمایش داده می‌شود." />
<button class="btn" type="submit">ذخیره</button>
<a class="btn secondary" href="{{ route('admin.categories.index') }}">انصراف</a>
