<x-admin-layout title="دسته‌بندی جدید">
    <form class="card" method="POST" action="{{ route('admin.categories.store') }}">
        @include('admin.categories._form')
    </form>
</x-admin-layout>
