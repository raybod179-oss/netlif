<x-admin-layout title="دسته‌بندی‌ها">
    <p><a class="btn" href="{{ route('admin.categories.create') }}">+ دسته‌بندی جدید</a></p>

    <div class="card table-wrap">
        <table>
            <thead><tr><th>آیکن</th><th>نام</th><th>تعداد محصول</th><th></th></tr></thead>
            <tbody>
            @forelse ($categories as $category)
                <tr>
                    <td>{{ $category->icon }}</td>
                    <td>{{ $category->name }}</td>
                    <td>{{ $category->products_count }}</td>
                    <td class="row">
                        <a class="btn secondary sm" href="{{ route('admin.categories.edit', $category) }}">ویرایش</a>
                        <form method="POST" action="{{ route('admin.categories.destroy', $category) }}" onsubmit="return confirm('حذف شود؟')">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger sm" type="submit">حذف</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="4" class="muted">دسته‌بندی‌ای وجود ندارد.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
</x-admin-layout>
