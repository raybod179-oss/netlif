<x-admin-layout title="ویرایش دسته‌بندی">
    <form class="card" method="POST" action="{{ route('admin.categories.update', $category) }}">
        @method('PUT')
        @include('admin.categories._form')
    </form>
</x-admin-layout>
