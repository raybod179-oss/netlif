<x-admin-layout title="سفارش‌ها">
    <form class="row mb" method="GET" action="{{ route('admin.orders.index') }}">
        <select name="status" style="width:220px" onchange="this.form.submit()" aria-label="فیلتر وضعیت">
            <option value="">همه‌ی وضعیت‌ها</option>
            @foreach (config('shop.order_statuses') as $key => $label)
                <option value="{{ $key }}" @selected(request('status') === $key)>{{ $label }}</option>
            @endforeach
        </select>
        <noscript><button class="btn secondary" type="submit">فیلتر</button></noscript>
    </form>

    <div class="card table-wrap">
        <table>
            <thead><tr><th>شماره</th><th>مشتری</th><th>تاریخ</th><th>اقلام</th><th>مبلغ</th><th>وضعیت</th><th></th></tr></thead>
            <tbody>
            @forelse ($orders as $order)
                <tr>
                    <td>#{{ $order->id }}</td>
                    <td>{{ $order->user->name }}</td>
                    <td>{{ $order->created_at->format('Y/m/d H:i') }}</td>
                    <td>{{ $order->products_count }}</td>
                    <td><x-price :value="$order->total" /></td>
                    <td><x-order-status :order="$order" /></td>
                    <td><a class="btn secondary sm" href="{{ route('admin.orders.show', $order) }}">مشاهده</a></td>
                </tr>
            @empty
                <tr><td colspan="7" class="muted">سفارشی پیدا نشد.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    {{ $orders->links() }}
</x-admin-layout>
