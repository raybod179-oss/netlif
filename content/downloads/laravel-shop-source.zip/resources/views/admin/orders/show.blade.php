<x-admin-layout :title="'سفارش #'.$order->id">
    <div class="cols-2">
        <div class="card table-wrap">
            <table>
                <thead><tr><th>محصول</th><th>قیمت</th><th>تعداد</th><th>جمع</th></tr></thead>
                <tbody>
                @foreach ($order->products as $product)
                    <tr>
                        <td>{{ $product->name }}</td>
                        <td><x-price :value="$product->pivot->price" /></td>
                        <td>{{ $product->pivot->quantity }}</td>
                        <td><x-price :value="$product->pivot->price * $product->pivot->quantity" /></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <p class="row between mt"><strong>جمع کل</strong><x-price :value="$order->total" /></p>
        </div>

        <div class="card">
            <h3>مشتری</h3>
            <p>{{ $order->user->name }} — <span class="ltr">{{ $order->user->email }}</span></p>
            <h3>گیرنده</h3>
            <p>{{ $order->name }} — <span class="ltr">{{ $order->phone }}</span><br>{{ $order->city }}، {{ $order->address }}</p>
            @if ($order->note)<p class="muted">توضیحات: {{ $order->note }}</p>@endif

            <h3 class="mt">وضعیت: <x-order-status :order="$order" /></h3>
            @unless ($order->isCancelled())
                <form method="POST" action="{{ route('admin.orders.update', $order) }}" class="row">
                    @csrf
                    @method('PATCH')
                    <select name="status" style="width:200px" aria-label="وضعیت جدید">
                        @foreach (config('shop.order_statuses') as $key => $label)
                            <option value="{{ $key }}" @selected($order->status === $key)>{{ $label }}</option>
                        @endforeach
                    </select>
                    <button class="btn" type="submit">ثبت وضعیت</button>
                </form>
                <p class="muted small">با انتخاب «لغو شده»، موجودی محصولات به انبار برمی‌گردد و دیگر قابل تغییر نیست.</p>
            @endunless
            <a class="btn secondary mt" href="{{ route('admin.orders.index') }}">بازگشت</a>
        </div>
    </div>
</x-admin-layout>
