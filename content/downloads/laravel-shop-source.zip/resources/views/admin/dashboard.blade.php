<x-admin-layout title="داشبورد">
    <div class="grid stats mb">
        <div class="stat"><div class="n">{{ number_format($stats['products']) }}</div><div class="l">محصول</div></div>
        <div class="stat"><div class="n">{{ number_format($stats['categories']) }}</div><div class="l">دسته‌بندی</div></div>
        <div class="stat"><div class="n">{{ number_format($stats['orders']) }}</div><div class="l">سفارش</div></div>
        <div class="stat"><div class="n">{{ number_format($stats['customers']) }}</div><div class="l">مشتری</div></div>
        <div class="stat"><div class="n">{{ number_format($stats['revenue']) }}</div><div class="l">فروش ({{ config('shop.currency') }})</div></div>
    </div>

    <div class="cols-2">
        <div class="card">
            <h3>آخرین سفارش‌ها</h3>
            @forelse ($latestOrders as $order)
                <p class="row between">
                    <a href="{{ route('admin.orders.show', $order) }}">#{{ $order->id }} — {{ $order->user->name }}</a>
                    <span><x-order-status :order="$order" /> <x-price :value="$order->total" /></span>
                </p>
            @empty
                <p class="muted">سفارشی وجود ندارد.</p>
            @endforelse
        </div>

        <div class="card">
            <h3>کم‌موجود / ناموجود</h3>
            @forelse ($lowStock as $product)
                <p class="row between">
                    <a href="{{ route('admin.products.edit', $product) }}">{{ $product->name }}</a>
                    <span @class(['tag', 'danger' => $product->stock === 0, 'warn' => $product->stock > 0])>{{ $product->stock }} عدد</span>
                </p>
            @empty
                <p class="muted">همه‌ی محصولات موجودی کافی دارند.</p>
            @endforelse
        </div>
    </div>
</x-admin-layout>
