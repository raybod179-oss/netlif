<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
class EnsureVendor
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless($request->user()?->isVendor(), 403, 'فقط فروشندگان تأییدشده به این بخش دسترسی دارند.');
        return $next($request);
    }
}
