<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Payout;
use App\Services\Wallet;
use Illuminate\Http\Request;
class PayoutController extends Controller
{
    public function index() { return view('admin.payouts', ['payouts' => Payout::with('user')->orderByRaw("status = 'pending' desc")->latest()->paginate(20)]); }
    public function update(Request $request, Payout $payout, Wallet $wallet)
    {
        $action = $request->validate(['action' => 'required|in:paid,rejected'])['action'];
        abort_unless($payout->status === 'pending', 422);
        if ($action === 'paid') { $payout->update(['status' => 'paid']); } else { $wallet->rejectPayout($payout); }
        return back()->with('success', 'درخواست برداشت به‌روز شد.');
    }
}
