<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
class VendorController extends Controller
{
    public function index() { return view('admin.vendors', ['vendors' => User::whereNotNull('vendor_status')->latest()->paginate(20)]); }
    public function update(Request $request, User $user)
    {
        $data = $request->validate(['vendor_status' => 'required|in:approved,rejected']);
        abort_if($user->vendor_status === null, 404);
        $user->forceFill($data)->save();
        return back()->with('success', 'وضعیت فروشنده به‌روز شد.');
    }
}
