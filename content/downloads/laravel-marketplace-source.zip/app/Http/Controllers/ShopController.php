<?php
namespace App\Http\Controllers;
use App\Models\{Product, User};
class ShopController extends Controller
{
    public function show(User $user)
    {
        abort_unless($user->isVendor(), 404);
        $products = Product::active()->with('category')->where('vendor_id', $user->id)->latest()->paginate(12);
        return view('shop-page', ['vendor' => $user, 'products' => $products]);
    }
}
