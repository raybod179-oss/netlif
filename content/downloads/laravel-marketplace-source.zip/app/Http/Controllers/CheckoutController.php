<?php

namespace App\Http\Controllers;

use App\Http\Requests\CheckoutRequest;
use App\Models\Product;
use App\Services\Cart;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class CheckoutController extends Controller
{
    public function create(Cart $cart): View|RedirectResponse
    {
        if ($cart->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'سبد خرید شما خالی است.');
        }

        return view('checkout.create', [
            'items' => $cart->items(),
            'total' => $cart->total(),
        ]);
    }

    public function store(CheckoutRequest $request, Cart $cart): RedirectResponse
    {
        $lines = $cart->items();

        if ($lines->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'سبد خرید شما خالی است.');
        }

        try {
            // همه‌چیز یا هیچ‌چیز: اگر وسط کار خطا بیاید، هیچ سفارش نیمه‌کاره‌ای ذخیره نمی‌شود.
            $order = DB::transaction(function () use ($request, $lines) {
                $ids = $lines->map(fn ($line) => $line['product']->id)->all();

                // قفل ردیف‌ها تا دو خرید هم‌زمان، موجودی را منفی نکنند
                $products = Product::query()->whereIn('id', $ids)->lockForUpdate()->get()->keyBy('id');

                $total = 0;

                foreach ($lines as $line) {
                    $product = $products->get($line['product']->id);

                    if (! $product || ! $product->is_active || $product->stock < $line['quantity']) {
                        throw new RuntimeException("موجودی «{$line['product']->name}» کافی نیست. سبد را بررسی کنید.");
                    }

                    $total += $product->price * $line['quantity'];
                }

                $order = $request->user()->orders()->create([
                    ...$request->validated(),
                    'status' => 'pending',
                    'total' => $total,
                ]);

                foreach ($lines as $line) {
                    $product = $products->get($line['product']->id);

                    $order->products()->attach($product->id, [
                        'quantity' => $line['quantity'],
                    'vendor_id' => $product->vendor_id,
                    'commission' => $product->vendor_id
                        ? (int) round($product->price * $line['quantity'] * config('shop.commission_percent') / 100)
                        : 0,
                        'price' => $product->price,
                    ]);

                    $product->decrement('stock', $line['quantity']);
                }

                return $order;
            });
        } catch (RuntimeException $e) {
            return redirect()->route('cart.index')->with('error', $e->getMessage());
        }

        $cart->clear();

        return redirect()->route('orders.show', $order)->with('success', 'سفارش شما با موفقیت ثبت شد. ممنون از خرید شما!');
    }
}
