<?php
namespace App\Services;
use App\Models\{Order, Payout, User, WalletTransaction};
use Illuminate\Support\Facades\DB;
use RuntimeException;

class Wallet
{
    public function balance(User $user): int
    {
        return (int) WalletTransaction::where('user_id', $user->id)->sum('amount');
    }

    /** وقتی سفارش «تحویل داده شد»، سهم هر فروشنده (قیمت − کمیسیون) به کیف پولش واریز می‌شود. */
    public function settle(Order $order): void
    {
        DB::transaction(function () use ($order) {
            $byVendor = DB::table('order_product')->where('order_id', $order->id)->whereNotNull('vendor_id')->get()->groupBy('vendor_id');
            foreach ($byVendor as $vendorId => $lines) {
                $net = $lines->sum(fn ($l) => $l->price * $l->quantity - $l->commission);
                WalletTransaction::firstOrCreate(
                    ['user_id' => $vendorId, 'order_id' => $order->id, 'type' => 'sale'],
                    ['amount' => $net, 'note' => "سفارش #{$order->id}"]
                );
            }
        });
    }

    public function requestPayout(User $user, int $amount): Payout
    {
        return DB::transaction(function () use ($user, $amount) {
            User::whereKey($user->id)->lockForUpdate()->first();   // جلوگیری از دو برداشت هم‌زمان
            if ($amount < config('shop.min_payout') || $amount > $this->balance($user)) {
                throw new RuntimeException('مبلغ برداشت معتبر نیست یا از موجودی بیشتر است.');
            }
            $payout = Payout::create(['user_id' => $user->id, 'amount' => $amount]);
            WalletTransaction::create(['user_id' => $user->id, 'type' => 'payout', 'amount' => -$amount, 'note' => "درخواست برداشت #{$payout->id}"]);
            return $payout;
        });
    }

    public function rejectPayout(Payout $payout): void
    {
        DB::transaction(function () use ($payout) {
            if ($payout->status !== 'pending') { return; }
            $payout->update(['status' => 'rejected']);
            WalletTransaction::create(['user_id' => $payout->user_id, 'type' => 'refund', 'order_id' => null, 'amount' => $payout->amount, 'note' => "رد برداشت #{$payout->id}"]);
        });
    }
}
