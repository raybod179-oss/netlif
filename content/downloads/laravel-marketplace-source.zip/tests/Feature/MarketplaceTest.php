<?php
namespace Tests\Feature;
use App\Models\{Category, Order, Product, User};
use App\Services\Wallet;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class MarketplaceTest extends TestCase
{
    use RefreshDatabase;

    private function user(string $email, array $extra = []): User
    {
        return User::forceCreate(array_merge(['name' => 'T', 'email' => $email, 'password' => bcrypt('password'), 'role' => 'customer'], $extra));
    }

    public function test_non_vendor_cannot_open_vendor_panel(): void
    {
        $this->actingAs($this->user('a@t.test'))->get('/vendor')->assertForbidden();
        $this->actingAs($this->user('v@t.test', ['vendor_status' => 'approved']))->get('/vendor')->assertOk();
    }

    public function test_vendor_cannot_edit_other_vendors_product(): void
    {
        $cat = Category::create(['name' => 'c']);
        $a = $this->user('a@t.test', ['vendor_status' => 'approved']);
        $b = $this->user('b@t.test', ['vendor_status' => 'approved']);
        $p = Product::create(['vendor_id' => $a->id, 'category_id' => $cat->id, 'name' => 'x', 'description' => 'd', 'price' => 10000, 'stock' => 1, 'is_active' => true]);
        $this->actingAs($b)->get("/vendor/products/{$p->id}/edit")->assertForbidden();
    }

    public function test_settlement_credits_vendor_minus_commission_once(): void
    {
        $cat = Category::create(['name' => 'c']);
        $v = $this->user('v@t.test', ['vendor_status' => 'approved']);
        $buyer = $this->user('b@t.test');
        $p = Product::create(['vendor_id' => $v->id, 'category_id' => $cat->id, 'name' => 'x', 'description' => 'd', 'price' => 100000, 'stock' => 5, 'is_active' => true]);
        $order = Order::create(['user_id' => $buyer->id, 'status' => 'pending', 'total' => 200000, 'name' => 'n', 'phone' => '0', 'city' => 'c', 'address' => 'a']);
        DB::table('order_product')->insert(['order_id' => $order->id, 'product_id' => $p->id, 'quantity' => 2, 'price' => 100000, 'vendor_id' => $v->id, 'commission' => 20000]);

        $order->update(['status' => 'completed']);
        $order->update(['status' => 'completed']);   // دوباره: نباید دوباره واریز شود
        app(Wallet::class)->settle($order);

        $this->assertSame(180000, app(Wallet::class)->balance($v));
    }
}
