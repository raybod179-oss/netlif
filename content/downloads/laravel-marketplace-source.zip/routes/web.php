<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ShopController;
use App\Http\Controllers\Vendor;
use App\Http\Middleware\CheckRole;
use App\Http\Middleware\EnsureVendor;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| بخش عمومی (مهمان هم می‌بیند)
|--------------------------------------------------------------------------
*/
Route::get('/', HomeController::class)->name('home');

Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{product}', [ProductController::class, 'show'])->name('products.show');

// سبد خرید (در Session؛ مهمان هم می‌تواند اضافه کند)
Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::post('/cart/{product}', [CartController::class, 'store'])->name('cart.store');
Route::patch('/cart/{product}', [CartController::class, 'update'])->name('cart.update');
Route::delete('/cart/{product}', [CartController::class, 'destroy'])->name('cart.destroy');
Route::delete('/cart', [CartController::class, 'clear'])->name('cart.clear');

/*
|--------------------------------------------------------------------------
| احراز هویت
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:6,1');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:6,1');
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

/*
|--------------------------------------------------------------------------
| فقط کاربر واردشده: پرداخت و سفارش‌ها
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {
    Route::get('/checkout', [CheckoutController::class, 'create'])->name('checkout.create');
    Route::post('/checkout', [CheckoutController::class, 'store'])->name('checkout.store');

    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
});

/*
|--------------------------------------------------------------------------
| پنل مدیریت: اول auth، بعد CheckRole (ترتیب مهم است)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth', CheckRole::class.':admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/', [Admin\DashboardController::class, 'index'])->name('dashboard');

        Route::resource('categories', Admin\CategoryController::class)->except('show');
        Route::resource('products', Admin\ProductController::class)->except('show');

        Route::get('/orders', [Admin\OrderController::class, 'index'])->name('orders.index');
        Route::get('/orders/{order}', [Admin\OrderController::class, 'show'])->name('orders.show');
        Route::patch('/orders/{order}', [Admin\OrderController::class, 'update'])->name('orders.update');
    });

/*
|--------------------------------------------------------------------------
| مارکت‌پلیس: صفحه‌ی فروشگاه، درخواست فروشندگی، پنل فروشنده، مدیریت فروشندگان
|--------------------------------------------------------------------------
*/
Route::get('/shops/{user}', [ShopController::class, 'show'])->name('shops.show');

Route::middleware('auth')->group(function () {
    Route::get('/vendor/apply', [Vendor\ApplyController::class, 'create'])->name('vendor.apply');
    Route::post('/vendor/apply', [Vendor\ApplyController::class, 'store'])->name('vendor.apply.store');
});

Route::middleware(['auth', EnsureVendor::class])->prefix('vendor')->name('vendor.')->group(function () {
    Route::get('/', [Vendor\DashboardController::class, 'index'])->name('dashboard');
    Route::resource('products', Vendor\ProductController::class)->except('show');
    Route::get('/orders', [Vendor\OrderController::class, 'index'])->name('orders');
    Route::get('/wallet', [Vendor\WalletController::class, 'index'])->name('wallet');
    Route::post('/wallet/payout', [Vendor\WalletController::class, 'payout'])->name('payout')->middleware('throttle:5,1');
});

Route::middleware(['auth', CheckRole::class.':admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/vendors', [Admin\VendorController::class, 'index'])->name('vendors.index');
    Route::patch('/vendors/{user}', [Admin\VendorController::class, 'update'])->name('vendors.update');
    Route::get('/payouts', [Admin\PayoutController::class, 'index'])->name('payouts.index');
    Route::patch('/payouts/{payout}', [Admin\PayoutController::class, 'update'])->name('payouts.update');
});
