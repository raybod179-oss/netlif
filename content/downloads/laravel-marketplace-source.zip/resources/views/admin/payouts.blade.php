<x-admin-layout title="برداشت‌ها"><link rel="stylesheet" href="{{ asset('css/market.css') }}">
<table class="mk-t"><tr><th>فروشنده</th><th>مبلغ</th><th>وضعیت</th><th></th></tr>
@foreach($payouts as $p)<tr><td>{{ $p->user->shop_name ?? $p->user->name }}</td><td><x-price :value="$p->amount" /></td><td>{{ ['pending'=>'در انتظار','paid'=>'پرداخت شد','rejected'=>'رد شد'][$p->status] }}</td>
<td>@if($p->status === 'pending')@foreach(['paid' => 'پرداخت شد', 'rejected' => 'رد'] as $a => $l)
<form method="POST" action="{{ route('admin.payouts.update', $p) }}" style="display:inline">@csrf @method('PATCH')<input type="hidden" name="action" value="{{ $a }}"><button class="mk-btn {{ $a === 'rejected' ? 'red' : '' }}">{{ $l }}</button></form>@endforeach @endif</td></tr>@endforeach</table>
{{ $payouts->links() }}</x-admin-layout>
