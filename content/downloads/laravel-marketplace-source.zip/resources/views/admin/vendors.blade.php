<x-admin-layout title="فروشندگان"><link rel="stylesheet" href="{{ asset('css/market.css') }}">
<table class="mk-t"><tr><th>نام</th><th>فروشگاه</th><th>ایمیل</th><th>وضعیت</th><th></th></tr>
@foreach($vendors as $v)<tr><td>{{ $v->name }}</td><td>{{ $v->shop_name }}</td><td>{{ $v->email }}</td><td>{{ ['pending'=>'در انتظار','approved'=>'تأیید شده','rejected'=>'رد شده'][$v->vendor_status] }}</td>
<td style="white-space:nowrap">@foreach(['approved' => 'تأیید', 'rejected' => 'رد'] as $s => $l)
<form method="POST" action="{{ route('admin.vendors.update', $v) }}" style="display:inline">@csrf @method('PATCH')<input type="hidden" name="vendor_status" value="{{ $s }}"><button class="mk-btn {{ $s === 'rejected' ? 'red' : '' }}">{{ $l }}</button></form>@endforeach</td></tr>@endforeach</table>
{{ $vendors->links() }}</x-admin-layout>
