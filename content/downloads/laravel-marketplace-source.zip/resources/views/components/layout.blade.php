@props(['title' => null])
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title ? $title.' | ' : '' }}{{ config('shop.name') }}</title>
    <link rel="stylesheet" href="{{ asset('css/shop.css') }}">
    <link rel="stylesheet" href="{{ asset('css/market.css') }}">
</head>
<body>
<header class="site-header">
    <div class="container bar">
        <a class="brand" href="{{ route('home') }}">🛍️ فروشگاه <span>لاراول</span></a>

        <nav class="nav" aria-label="منوی اصلی">
            <a href="{{ route('home') }}">خانه</a>
            <a href="{{ route('products.index') }}">محصولات</a>
            <a href="{{ route('cart.index') }}">
                سبد خرید
                @php($cartCount = app(\App\Services\Cart::class)->count())
                @if ($cartCount > 0)<span class="badge">{{ $cartCount }}</span>@endif
            </a>

            @auth
                <a href="{{ route('orders.index') }}">سفارش‌های من</a>
                @if (auth()->user()->isVendor())
                    <a href="{{ route('vendor.dashboard') }}">🏪 پنل فروشنده</a>
                @elseif (! auth()->user()->isAdmin())
                    <a href="{{ route('vendor.apply') }}">فروشنده شو</a>
                @endif
                @if (auth()->user()->isAdmin())
                    <a href="{{ route('admin.dashboard') }}">⚙️ پنل مدیریت</a>
                @endif
                <form class="inline-form" method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="linklike">خروج ({{ auth()->user()->name }})</button>
                </form>
            @else
                <a href="{{ route('login') }}">ورود</a>
                <a href="{{ route('register') }}">ثبت‌نام</a>
            @endauth
        </nav>

        <form class="search" method="GET" action="{{ route('products.index') }}" role="search">
            <input type="search" name="q" value="{{ request('q') }}" placeholder="جستجوی محصول…" aria-label="جستجو">
            <button class="btn sm" type="submit">جستجو</button>
        </form>
    </div>
</header>

<main class="container">
    <x-flash />
    {{ $slot }}
</main>

<footer class="site-footer">
    <div class="container">
        {{ config('shop.name') }} — {{ config('shop.tagline') }} · ساخته‌شده با Laravel {{ app()->version() }}
    </div>
</footer>
</body>
</html>
