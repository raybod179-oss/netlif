<x-layout :title="$vendor->shop_name">
<h1>{{ $vendor->shop_name }}</h1>
<div class="product-grid">@foreach($products as $product)<x-product-card :product="$product" />@endforeach</div>
{{ $products->links() }}</x-layout>
