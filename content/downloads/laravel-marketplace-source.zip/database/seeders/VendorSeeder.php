<?php
namespace Database\Seeders;
use App\Models\{Category, Product, User};
use Illuminate\Database\Seeder;
class VendorSeeder extends Seeder
{
    public function run(): void
    {
        $vendor = User::firstOrNew(['email' => 'vendor@shop.test']);
        $vendor->forceFill(['name' => 'فروشنده‌ی نمونه', 'role' => 'customer', 'vendor_status' => 'approved',
            'shop_name' => 'فروشگاه نمونه‌ی Rayvo', 'password' => 'password', 'email_verified_at' => now()])->save();
        $cat = Category::first();
        foreach (range(1, 6) as $i) {
            Product::create(['vendor_id' => $vendor->id, 'category_id' => $cat->id, 'name' => "محصول فروشنده {$i}",
                'description' => 'محصول نمونه‌ی فروشنده برای نمایش مارکت‌پلیس.', 'price' => 100000 * $i, 'stock' => 20, 'is_active' => true]);
        }
    }
}
