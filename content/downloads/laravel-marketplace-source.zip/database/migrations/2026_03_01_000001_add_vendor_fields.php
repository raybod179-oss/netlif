<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $t) {
            $t->string('vendor_status')->nullable()->index();   // pending | approved | rejected
            $t->string('shop_name')->nullable();
        });
        Schema::table('products', function (Blueprint $t) {
            $t->foreignId('vendor_id')->nullable()->constrained('users')->nullOnDelete();
        });
        Schema::table('order_product', function (Blueprint $t) {
            $t->foreignId('vendor_id')->nullable()->constrained('users')->nullOnDelete();
            $t->unsignedBigInteger('commission')->default(0);   // کمیسیون سایت برای این ردیف (snapshot)
        });
    }
    public function down(): void
    {
        Schema::table('order_product', function (Blueprint $t) { $t->dropConstrainedForeignId('vendor_id'); $t->dropColumn('commission'); });
        Schema::table('products', fn (Blueprint $t) => $t->dropConstrainedForeignId('vendor_id'));
        Schema::table('users', fn (Blueprint $t) => $t->dropColumn(['vendor_status', 'shop_name']));
    }
};
