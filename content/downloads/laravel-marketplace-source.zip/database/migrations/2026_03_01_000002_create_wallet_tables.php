<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void
    {
        Schema::create('wallet_transactions', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->foreignId('order_id')->nullable()->constrained()->nullOnDelete();
            $t->string('type');                 // sale | payout | refund
            $t->bigInteger('amount');           // مثبت = واریز، منفی = برداشت
            $t->string('note')->nullable();
            $t->timestamps();
            $t->unique(['user_id', 'order_id', 'type']);   // تسویه‌ی دوباره‌ی یک سفارش ممکن نیست
        });
        Schema::create('payouts', function (Blueprint $t) {
            $t->id();
            $t->foreignId('user_id')->constrained()->cascadeOnDelete();
            $t->unsignedBigInteger('amount');
            $t->string('status')->default('pending')->index();   // pending | paid | rejected
            $t->string('note')->nullable();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('payouts'); Schema::dropIfExists('wallet_transactions'); }
};
